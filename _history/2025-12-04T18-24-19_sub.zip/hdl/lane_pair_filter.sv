`default_nettype none

`timescale 1ns / 1ps

module lane_pair_filter #(
    parameter WIDTH = 706,
    parameter HEIGHT = 146
)(
    input wire clk, 
    input wire rst,
    
    input wire [3:0] cc_valid,
    input wire [10:0] cc_x [3:0],
    input wire [9:0] cc_y [3:0],
    input wire [31:0] cc_pixels [3:0],

    output logic [10:0] left_midpoint,
    output logic [10:0] right_midpoint,
    output logic [10:0] total_midpoint,
    output logic valid_midpoints
);

    localparam MID_H = WIDTH / 2; // does this division take extensive time to run?

    logic [3:0] left_cc_top;
    // for calculating 1/4 weighting
    logic [10:0] left_cc_top_w_calc;
    logic [3:0] left_cc_bottom;
    // for calculating 3/4 weighting
    logic [10:0] left_cc_bottom_w_calc;

    logic [3:0] right_cc_top;
    // for calculating 1/4 weighting
    logic [10:0] right_cc_top_w_calc;
    logic [3:0] right_cc_bottom;
    // for calculating 3/4 weighting
    logic [10:0] right_cc_bottom_w_calc;

    logic [10:0] left_ccs_midpoint;
    logic [10:0] right_ccs_midpoint;
    logic [10:0] total_midpoint;

    always_ff @(posedge clk) begin
        if (rst) begin
            left_cc_top <= 0;
            left_cc_top_w_calc <= 0;
            left_cc_bottom <= 0;
            left_cc_bottom_w_calc <= 0;
            right_cc_top <= 0;
            right_cc_top_w_calc <= 0;
            right_cc_bottom <= 0;
            right_cc_bottom_w_calc <= 0;
            left_ccs_midpoint <= 0;
            right_ccs_midpoint <= 0;
            total_midpoint <= 0;

        end
        if (cc_valid) begin
            for (integer i = 1; i < 5; i = i + 1) begin
                // check if it's left
                if (cc_x[i] < MID_H) begin
                    // sort top left and bottom left
                    if (left_cc_top > 0) begin
                        if (cc_y[i] > cc_y[left_cc_top]) begin
                            left_cc_bottom <= left_cc_top;
                            left_cc_top <= i;
                        end else begin
                            left_cc_bottom <= i;
                        end
                    end else begin
                        // in case top hasn't been set yet
                        left_cc_top <= i;
                    end   
                // else right
                end else begin
                    // sort top right and bottom left
                    if (right_cc_top > 0) begin
                        if (cc_y[i] > cc_y[right_cc_top]) begin
                            right_cc_bottom <= right_cc_top;
                            right_cc_top <= i;
                        end else begin
                            right_cc_bottom <= i;
                        end
                    end else begin
                        right_cc_top <= 1;
                    end
                end
            end
        end
        if ((left_cc_bottom > 0) && (left_cc_top > 0)) begin
            // perform mult by 3/4 for bottom
            left_cc_bottom_w_calc <= (cc_x[left_cc_bottom] * 2'b11) >> 2;
            // perform mult by 1/4 for top
            left_cc_top_w_calc <= (cc_x[left_cc_top]) >> 2;

            // calc midpoint for left ccs
            left_ccs_midpoint <= (left_cc_bottom_w_calc + left_cc_top_w_calc) >> 1;
        end
        if ((right_cc_bottom > 0) && (right_cc_top > 0)) begin
            // perform mult by 3/4 for bottom
            right_cc_bottom_w_calc <= (cc_x[right_cc_bottom] * 2'b11) >> 2;

            // perform mult by 1/4 for top
            right_cc_top_w_calc <= (cc_x[right_cc_top]) >> 2;

            // calc midpoint for left ccs
            right_ccs_midpoint <= (right_cc_bottom_w_calc + right_cc_top_w_calc) >> 1;
        end
        if ((left_ccs_midpoint > 0) && (right_ccs_midpoint > 0)) begin
            left_cc_top <= 0;
            left_cc_bottom <= 0;
            left_ccs_midpoint <= 0;

            right_cc_top <= 0;
            right_cc_bottom <= 0;
            right_ccs_midpoint <= 0;

            total_midpoint <= (left_ccs_midpoint + right_ccs_midpoint) >> 1;
            left_midpoint <= left_ccs_midpoint;
            right_midpoint <= right_ccs_midpoint;
            valid_midpoints <= 1;
        end
    end
endmodule

`default_nettype wire