import os
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
from cocotb.runner import get_runner


def build_test_frame():
    frame = []
    for dx in range(6):
        frame.append((1, 10 + dx, 20 + dx // 2))
    for dx in range(3):
        frame.append((2, 40 + dx, 60))
    for dx in range(8):
        frame.append((3, 100 + dx, 70 + (dx % 2)))
    return frame


async def drive_frame(dut, pixels):
    dut.cc_pixel_valid.value = 0
    dut.cc_pixel_last.value = 0
    await RisingEdge(dut.clk)

    for label, h, v in pixels:
        dut.cc_pixel_valid.value = 1
        dut.cc_pixel_label.value = label
        dut.cc_pixel_h.value = h
        dut.cc_pixel_v.value = v
        dut.cc_pixel_last.value = 0
        await RisingEdge(dut.clk)

    dut.cc_pixel_valid.value = 0
    dut.cc_pixel_label.value = 0
    dut.cc_pixel_h.value = 0
    dut.cc_pixel_v.value = 0
    dut.cc_pixel_last.value = 1
    await RisingEdge(dut.clk)
    dut.cc_pixel_last.value = 0


@cocotb.test()
async def test_lane_pair_pipeline(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())

    dut.rst.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    await RisingEdge(dut.clk)

    await drive_frame(dut, build_test_frame())

    timeout = 50000
    lanes_seen = False
    blob_seen = False
    for _ in range(timeout):
        await RisingEdge(dut.clk)
        blob_mask = int(dut.blob_valid.value)
        if not blob_seen and blob_mask != 0:
            def safe(signal):
                return int(signal.value) if signal.value.is_resolvable else None
            dut._log.info(
                "blob_valid=%s x=%s y=%s area=%s",
                dut.blob_valid.value.binstr,
                [safe(dut.blob_x0), safe(dut.blob_x1), safe(dut.blob_x2), safe(dut.blob_x3)],
                [safe(dut.blob_y0), safe(dut.blob_y1), safe(dut.blob_y2), safe(dut.blob_y3)],
                [safe(dut.blob_area0), safe(dut.blob_area1), safe(dut.blob_area2), safe(dut.blob_area3)],
            )
            blob_seen = True
        if dut.lanes_valid.value:
            lanes_seen = True
            break

    if not lanes_seen:
        def safe(signal):
            return int(signal.value) if signal.value.is_resolvable else None

        dut._log.error(
            "final: blob_valid=%s lanes_valid=%s left=%s right=%s x=%s y=%s area=%s",
            dut.blob_valid.value.binstr,
            int(dut.lanes_valid.value),
            safe(dut.lane_left_x),
            safe(dut.lane_right_x),
            [safe(dut.blob_x0), safe(dut.blob_x1), safe(dut.blob_x2), safe(dut.blob_x3)],
            [safe(dut.blob_y0), safe(dut.blob_y1), safe(dut.blob_y2), safe(dut.blob_y3)],
            [safe(dut.blob_area0), safe(dut.blob_area1), safe(dut.blob_area2), safe(dut.blob_area3)],
        )
        assert lanes_seen, "Lane pairing never asserted valid"
    left_x = int(dut.lane_left_x.value)
    right_x = int(dut.lane_right_x.value)
    left_y = int(dut.lane_left_y.value)
    right_y = int(dut.lane_right_y.value)

    assert left_x == 12, f"Unexpected left lane X {left_x}"
    assert left_y == 21, f"Unexpected left lane Y {left_y}"
    assert right_x == 103, f"Unexpected right lane X {right_x}"
    assert right_y == 70, f"Unexpected right lane Y {right_y}"


def test_lane_pipeline_runner():
    proj_path = Path(__file__).resolve().parent.parent
    sim_build_dir = proj_path / "sim_build_lane_pipeline"
    sim = os.getenv("SIM", "icarus")

    sources = [
        proj_path / "hdl" / "lane_pipeline_tb_top.sv",
        proj_path / "hdl" / "ccl_calc.sv",
        proj_path / "hdl" / "divider.sv",
        proj_path / "hdl" / "lane_pair_filter.sv",
    ]

    runner = get_runner(sim)
    runner.build(
        sources=sources,
        hdl_toplevel="lane_pipeline_tb_top",
        build_dir=str(sim_build_dir),
        timescale=("1ns", "1ps"),
        always=True,
        waves=True,
    )
    runner.test(
        hdl_toplevel="lane_pipeline_tb_top",
        test_module="test_lane_pipeline",
        build_dir=str(sim_build_dir),
        waves=True,
    )


if __name__ == "__main__":
    test_lane_pipeline_runner()

