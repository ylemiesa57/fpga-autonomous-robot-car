import os
import sys
import random
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
from cocotb.runner import get_runner

# --- Reference Implementation ---

def connected_components(frame):
    """Reference 8-connected CCL implementation using Union-Find"""
    height = len(frame)
    width = len(frame[0])
    labels = [[0] * width for _ in range(height)]
    parent = {}

    def make_set(label):
        parent[label] = label

    def find(label):
        # Path compression
        root = label
        while parent[root] != root:
            root = parent[root]
        
        curr = label
        while curr != root:
            nxt = parent[curr]
            parent[curr] = root
            curr = nxt
        return root

    def union(a, b):
        root_a = find(a)
        root_b = find(b)
        if root_a != root_b:
            # Simple union (smallest ID as root for consistency)
            if root_a < root_b:
                parent[root_b] = root_a
            else:
                parent[root_a] = root_b

    next_label = 1
    for y in range(height):
        for x in range(width):
            if frame[y][x] == 0:
                continue

            # Check 8-connectivity neighbors already scanned:
            # Left, Top-Left, Top, Top-Right
            neighbors = []
            if x > 0 and labels[y][x-1] != 0: neighbors.append(labels[y][x-1])             # L
            if x > 0 and y > 0 and labels[y-1][x-1] != 0: neighbors.append(labels[y-1][x-1]) # NW
            if y > 0 and labels[y-1][x] != 0: neighbors.append(labels[y-1][x])             # N
            if x < width - 1 and y > 0 and labels[y-1][x+1] != 0: neighbors.append(labels[y-1][x+1]) # NE

            if not neighbors:
                chosen = next_label
                make_set(chosen)
                next_label += 1
            else:
                # Choose minimum label as base
                chosen = min(neighbors)
                # Union all neighbors
                for n in neighbors:
                    if n != chosen:
                        union(chosen, n)
            
            labels[y][x] = chosen

    # Relabel based on final roots
    result = [[0] * width for _ in range(height)]
    for y in range(height):
        for x in range(width):
            lab = labels[y][x]
            result[y][x] = 0 if lab == 0 else find(lab)
    return result

# --- Test Utilities ---

def flatten_frame(frame):
    for row in frame:
        for bit in row:
            yield bit

async def drive_frame(dut, frame):
    for bit in flatten_frame(frame):
        dut.s_axis_data.value = bit
        dut.s_axis_valid.value = 1
        while True:
            await RisingEdge(dut.clk)
            if dut.s_axis_ready.value.integer == 1:
                break
        dut.s_axis_valid.value = 0
        # Random gap between pixels for stress testing
        if random.random() < 0.3:
            await RisingEdge(dut.clk)
            
    dut.s_axis_data.value = 0
    await RisingEdge(dut.clk)

async def collect_outputs(dut, total_pixels, timeout_cycles=50000):
    records = []
    seen_last = False
    max_cycles = max(timeout_cycles, total_pixels * 10)
    for _ in range(max_cycles):
        await RisingEdge(dut.clk)
        if dut.m_axis_valid.value.integer == 1:
            x = int(dut.m_axis_x.value)
            y = int(dut.m_axis_y.value)
            label = int(dut.m_axis_label.value)
            records.append((x, y, label))
            if dut.m_axis_last.value.integer == 1:
                seen_last = True
            if len(records) == total_pixels and seen_last:
                return records
    raise AssertionError(
        f"Timeout waiting for {total_pixels} outputs; got {len(records)} entries"
    )

# --- Test Case ---

@cocotb.test()
async def test_ccl_randomized(dut):
    """Rigorous randomized test for CCL 8-connectivity"""
    
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    
    # Read parameters from DUT
    # Note: If params are not accessible, use defaults or passed args
    try:
        WIDTH = int(dut.WIDTH.value)
        HEIGHT = int(dut.HEIGHT.value)
    except:
        WIDTH = 10
        HEIGHT = 8
    
    print(f"Testing with Size: {WIDTH}x{HEIGHT}")
    
    NUM_FRAMES = 1 # Number of random patterns to test
    
    # Global reset before streaming frames
    dut.rst.value = 1
    dut.s_axis_valid.value = 0
    dut.m_axis_ready.value = 1  # Sink always ready
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    await RisingEdge(dut.clk)

    for frame_idx in range(NUM_FRAMES):
        print(f"--- Frame {frame_idx+1}/{NUM_FRAMES} ---")
        
        # 1. Generate Random Frame (25% density)
        frame = [[1 if random.random() < 0.25 else 0 for _ in range(WIDTH)] for _ in range(HEIGHT)]
        
        # Ensure some interesting features (optional manual overrides)
        if frame_idx == 0:
            # Empty frame
            frame = [[0] * WIDTH for _ in range(HEIGHT)]
        elif frame_idx == 1:
            # Full frame
            frame = [[1] * WIDTH for _ in range(HEIGHT)]
        
        # 2. Calculate Reference Output
        ref_grid = connected_components(frame)
        expected_stream = [
            (x, y, ref_grid[y][x]) for y in range(HEIGHT) for x in range(WIDTH)
        ]
        
        total_pixels = WIDTH * HEIGHT
        
        collector = cocotb.start_soon(collect_outputs(dut, total_pixels))
        await drive_frame(dut, frame)
        
        # 4. Verify
        outputs = await collector
        
        assert len(outputs) == total_pixels
        
        # Equivalence Checking
        # Because labels may be assigned differently (e.g. 1,2 vs 2,1),
        # we verify the partition structure, not absolute values.
        
        ref_map = {} # Maps Reference_Label -> DUT_Label
        
        for idx, (obs, exp) in enumerate(zip(outputs, expected_stream)):
            obs_x, obs_y, obs_label = obs
            exp_x, exp_y, exp_label = exp
            
            # Check Coordinates
            assert (obs_x, obs_y) == (exp_x, exp_y), \
                f"Coordinate mismatch at idx {idx}: Got ({obs_x},{obs_y}), Exp ({exp_x},{exp_y})"
            
            # Check Background Consistency
            if exp_label == 0:
                assert obs_label == 0, f"Background mismatch at ({obs_x},{obs_y}). Exp 0, Got {obs_label}"
                continue
            else:
                assert obs_label != 0, f"Foreground mismatch at ({obs_x},{obs_y}). Exp {exp_label}, Got 0"
            
            # Check Label Consistency (Bijective Mapping)
            if exp_label in ref_map:
                # We have seen this reference label before; DUT must output the SAME label as before
                expected_dut_label = ref_map[exp_label]
                assert obs_label == expected_dut_label, \
                    f"Label Inconsistency at ({obs_x},{obs_y}). Ref Label {exp_label} maps to DUT {expected_dut_label}, but got {obs_label}"
            else:
                # New reference label.
                # Ensure the DUT label we just got hasn't been used for a DIFFERENT reference label.
                if obs_label in ref_map.values():
                    # Find collision
                    old_ref = [k for k, v in ref_map.items() if v == obs_label][0]
                    raise AssertionError(f"Label Collision at ({obs_x},{obs_y}). DUT Label {obs_label} already mapped to Ref {old_ref}, now trying to map to Ref {exp_label}")
                
                # Register mapping
                ref_map[exp_label] = obs_label
        
        print("Verification Successful.")

# --- Runner ---

def test_ccl_8conn_runner():
    hdl_toplevel_lang = os.getenv("HDL_TOPLEVEL_LANG", "verilog")
    sim = os.getenv("SIM", "icarus")
    proj_path = Path(__file__).resolve().parent.parent
    sim_build_dir = proj_path / "sim_build_ccl"
    
    # Ensure sim directory is in path for cocotb to find the test module
    sys.path.append(str(proj_path / "sim"))

    sources = [
        proj_path / "hdl" / "ccl_8conn.sv",
        proj_path / "hdl" / "xilinx_true_dual_port_read_first_1_clock_ram.v",
    ]
    
    toplevel = "tpss_ccl_8conn"
    
    runner = get_runner(sim)
    runner.build(
        sources=sources,
        hdl_toplevel=toplevel, 
        always=True,  # Force rebuild so an old perspective binary is not reused
        build_args=["-Wall"],
        parameters={
            "WIDTH": 177,      # Match downsampled ROI throughput
            "HEIGHT": 36,
            "LABEL_BITS": 12
        },
        timescale=("1ns", "1ps"),
        build_dir=str(sim_build_dir),
        waves=True,
    )
    runner.test(
        hdl_toplevel=toplevel,
        test_module=os.path.basename(__file__).replace(".py", ""),
        build_dir=str(sim_build_dir),
        waves=True,
    )

if __name__ == "__main__":
    test_ccl_8conn_runner()
