#!/usr/bin/env python3

# Source code from: Vivado HLS

# Simple BEV LUT generator without numpy dependency

# Configuration matches your (downsampled) ROI/BEV dimensions
BEV_WIDTH = 177
BEV_HEIGHT = 36
ROI_WIDTH = 177
ROI_HEIGHT = 36

# Simple identity mapping for now - replace with actual homography matrix
# This creates a basic mapping that you can calibrate later

with open("data/bev_lut.mem", "w") as f:
    for v in range(BEV_HEIGHT):
        for u in range(BEV_WIDTH):
            # Simple linear mapping (replace with actual homography)
            src_x = int((u / BEV_WIDTH) * ROI_WIDTH)
            src_y = int((v / BEV_HEIGHT) * ROI_HEIGHT)
            
            # Bounds check
            src_x = max(0, min(src_x, ROI_WIDTH - 1))
            src_y = max(0, min(src_y, ROI_HEIGHT - 1))
            
            # Convert 2D (x,y) to 1D Linear Address
            linear_addr = src_y * ROI_WIDTH + src_x
            
            # Write to file in HEX format (17 bits max = 5 hex digits)
            f.write(f"{linear_addr:05X}\n")

print(f"Generated bev_lut.mem with {BEV_WIDTH*BEV_HEIGHT} entries.")
print(f"Each entry is a 17-bit address into the ROI BRAM (max: {ROI_WIDTH * ROI_HEIGHT - 1})")

