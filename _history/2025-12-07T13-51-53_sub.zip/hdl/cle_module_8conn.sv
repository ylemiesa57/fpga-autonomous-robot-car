`timescale 1ns / 1ps
`default_nettype none

// In this module, we implement Connected Component Labeling (CCL) with CLE-style 8-connectivity,
// which means our pixel connectivity considers all 8 neighbors (up, down, left, right, and diagonals).
// We are using parameters so we can adjust image dimensions and other settings for our experiments or deployments.
// We also use AXI stream interfaces for transferring pixel data efficiently.
// The 8-connectivity aspect lets us explore more realistic object extraction in binary images.
//
// Our approach uses two clear passes through the image data:
//   Pass 1: We scan the image to assign provisional labels, record any equivalence (conflicting) labels that indicate contiguous regions should be merged, and store results in BRAM.
//   Pass 2: We then read the provisional labels from BRAM, resolve connected regions using our equivalence (union-find) mapping, and output the final labeled pixels.

module cle_module_8conn #(
    parameter int WIDTH = 177,
    parameter int HEIGHT = 36,
    parameter int LABEL_BITS = 12,
    parameter int MAX_COMPONENTS = 16   // Here we set a ceiling on the maximum number of unique connected components (blobs) we expect in our input; this helps us manage hardware resources.
)(
    input wire clk,
    input wire rst,

    // These are our signals for streaming binary pixels into the module.
    input wire s_axis_valid,
    input wire s_axis_data,             // Encodes whether the current pixel is foreground (1) or background (0)
    output logic s_axis_ready,

    // And these signals carry labeled output pixels with their coordinates to downstream hardware.
    output logic m_axis_valid,
    output logic [LABEL_BITS-1:0] m_axis_label,
    output logic [$clog2(WIDTH)-1:0] m_axis_x,
    output logic [$clog2(HEIGHT)-1:0] m_axis_y,
    output logic m_axis_last,
    input wire m_axis_ready
);

    // --- Our Parameter Definitions and Derived Constants ---
    localparam TOTAL_PIXELS = WIDTH * HEIGHT; // The total number of pixels in our input image.
    localparam ADDR_BITS = $clog2(TOTAL_PIXELS); // Sufficient address width to index every pixel.
    localparam X_BITS = $clog2(WIDTH);
    localparam Y_BITS = $clog2(HEIGHT);
    localparam EQUIV_BITS = $clog2(MAX_COMPONENTS + 1); // Needed to encode all possible component labels plus a '0' background.

    // --- Finite State Machine (FSM) Definition ---
    // We encode our various processing states for clear understanding and easier debugging.
    typedef enum logic [2:0] {
        IDLE,
        PASS1_WAIT,         // Waiting for a new pixel sample to start processing
        PASS1_LABEL,        // Actively assigning a label to the current pixel
        PASS1_CONFLICT,     // Merging labels due to detected conflict, updating our equivalence table
        PASS2_READ,         // Setting up to read provisional label(s) from BRAM
        PASS2_WAIT,         // Allowing time for BRAM output to stabilize (latency buffering)
        PASS2_OUTPUT,       // Emitting the final label and coordinates for a pixel
        DONE
    } state_t;

    state_t state;

    // --- BRAM Setup for Recording Labels in the First Pass ---
    // In our first pass, we store each pixel's provisional label at its image address.
    logic [ADDR_BITS-1:0] bram_addr_a, bram_addr_b;
    logic [LABEL_BITS-1:0] bram_din, bram_dout_a, bram_dout_b;
    logic bram_we;

    xilinx_true_dual_port_read_first_1_clock_ram #(
        .RAM_WIDTH(LABEL_BITS),
        .RAM_DEPTH(TOTAL_PIXELS)
    ) label_bram (
        .addra(bram_addr_a),
        .clka(clk),
        .wea(bram_we),
        .dina(bram_din),
        .ena(1'b1),
        .rsta(rst),
        .regcea(1'b1),
        .douta(bram_dout_a),
        .addrb(bram_addr_b),
        .web(1'b0),
        .dinb('0),
        .enb(1'b1),  // Always enabled for reads; web=0 ensures no writes
        .rstb(rst),
        .regceb(1'b1),
        .doutb(bram_dout_b)
    );

    // --- Line Buffers for Neighbor Label Tracking ---
    // We keep two line buffers (as register arrays) for tracking labels.
    // prev_row records labels from the row immediately above the working row,
    // curr_row records labels for the row we're currently populating (and reading from).
    logic [LABEL_BITS-1:0] prev_row [0:WIDTH-1];
    logic [LABEL_BITS-1:0] curr_row [0:WIDTH-1];

    // --- Equivalence Table for Union-Find Operations ---
    // This table tracks connected component merging outcomes.
    // At first, each label points to itself. As we find regions are connected, we update this table so labels belonging to the same component all point at a single 'root' label.
    logic [LABEL_BITS-1:0] equiv [0:MAX_COMPONENTS-1];

    // --- Utility Variables for Pixel Tracking and Label Assignment ---
    logic [ADDR_BITS-1:0] pixel_idx;      // Running index through each pixel in order (scanline raster order)
    logic [X_BITS-1:0] curr_x;           // Horizontal pixel coordinate for the pixel currently being handled
    logic [Y_BITS-1:0] curr_y;           // Vertical pixel coordinate for the pixel currently being handled
    logic [LABEL_BITS-1:0] next_label;   // The next available label to dispense when a new component is found
    logic [LABEL_BITS-1:0] chosen_label; // The label we assign to the current pixel after checking neighbors
    logic curr_pixel;                    // Current pixel's binary value (are we working on a foreground pixel?)

    // --- Variables for Conflict Detection and Handling ---
    logic [LABEL_BITS-1:0] conflict_label1, conflict_label2; // These hold the two labels in conflict (needing resolution in the table)
    logic has_conflict;                                      // True if we've detected conflicting labels to merge

    // --- State Variables for Second Pass ---
    logic [ADDR_BITS-1:0] p2_pixel_idx;      // Second pass: our index through output pixels
    logic [X_BITS-1:0] p2_x;                 // Second pass: x coordinate for output
    logic [Y_BITS-1:0] p2_y;                 // Second pass: y coordinate
    logic [1:0] bram_read_delay;             // Use this to model/handle BRAM latency during the read phase

    // --- Temporary Variables for Internal Checks and Computation ---
    // We use these for steps like finding minimal neighbor labels or tracking state inside loops 
    logic [LABEL_BITS-1:0] min_label_tmp, other_label_tmp;
    logic found_conflict_tmp;
    
    // For union-find root traversal and result holding in the equivalence table
    logic [LABEL_BITS-1:0] root1_tmp, root2_tmp, min_root_tmp, max_root_tmp;
    logic [LABEL_BITS-1:0] raw_label_tmp, final_label_tmp;

    // --- Variables for Capturing Neighbor Labels in 8-Connectivity ---
    // L, NW, N, NE represent Left, Northwest, North, and Northeast pixel neighbors, respectively.
    logic [LABEL_BITS-1:0] L, NW, N, NE;
    logic L_valid, NW_valid, N_valid, NE_valid;

    // --- Combinational Logic for Neighbor Lookup ---
    // Here, we construct the logic to extract neighbor labels for our current pixel, taking care to honor the image boundaries.
    // We set labels to '0' and validity flags to 0 unless a corresponding neighbor exists and is labeled foreground.
    always_comb begin
        // We initialize all neighbors as background and invalid by default
        L = '0; NW = '0; N = '0; NE = '0;
        L_valid = 1'b0; NW_valid = 1'b0; N_valid = 1'b0; NE_valid = 1'b0;

        // The left neighbor exists only if we're not at the first column
        if (curr_x > 0) begin
            L = curr_row[curr_x - 1];
            L_valid = (L != '0);
        end

        // North-side neighbors exist only if we're not at the first row
        if (curr_y > 0) begin
            // Northwest neighbor: up one row and left one column
            if (curr_x > 0) begin
                NW = prev_row[curr_x - 1];
                NW_valid = (NW != '0);
            end

            // North neighbor: directly above
            N = prev_row[curr_x];
            N_valid = (N != '0);

            // Northeast neighbor: up one row and right one column (if not last column)
            if (curr_x < WIDTH - 1) begin
                NE = prev_row[curr_x + 1];
                NE_valid = (NE != '0);
            end
        end
    end

    // --- Function to Track Label Roots for Equivalence Table (Union-Find 'Find' Operation) ---
    // Recursively follow the equivalence table until we reach a root label (that points to itself).
    // We add a depth limiter to prevent synthesis issues if, hypothetically, a loop could occur due to a bug.
    
    
    //based off of the verilog implementation, function documentation here: https://www.chipverify.com/systemverilog/systemverilog-functions
    function automatic [LABEL_BITS-1:0] find_root(
        input [LABEL_BITS-1:0] label
    );
        logic [LABEL_BITS-1:0] current;
        integer depth;
        current = label;
        // Follow the equivalence chain.
        for (depth = 0; depth < MAX_COMPONENTS; depth = depth + 1) begin
            // We break out if we're at background, out of bounds, or already at a root label
            if (current == 0 || current >= MAX_COMPONENTS || equiv[current] == current) begin
                return current;
            end
            current = equiv[current];
        end
        return current;
    endfunction

    // --- Main State Machine: This Drives Image Scanning and Labeling ---
    integer i; // Used for initialization and buffer maintenance

    always_ff @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            pixel_idx <= '0;
            curr_x <= '0;
            curr_y <= '0;
            next_label <= 1;
            s_axis_ready <= 1'b0;
            m_axis_valid <= 1'b0;
            m_axis_last <= 1'b0;
            m_axis_label <= '0;
            m_axis_x <= '0;
            m_axis_y <= '0;
            bram_we <= 1'b0;
            bram_addr_a <= '0;
            bram_addr_b <= '0;
            bram_din <= '0;
            chosen_label <= '0;
            curr_pixel <= 1'b0;
            conflict_label1 <= '0;
            conflict_label2 <= '0;
            has_conflict <= 1'b0;
            p2_pixel_idx <= '0;
            p2_x <= '0;
            p2_y <= '0;
            bram_read_delay <= '0;

            // Here we initialize both our line buffers so that all their entries are marked as background (label 0).
            for (i = 0; i < WIDTH; i = i + 1) begin
                prev_row[i] <= '0;
                curr_row[i] <= '0;
            end

            // At the beginning, each potential label in the equivalence table refers to itself.
            for (i = 0; i < MAX_COMPONENTS; i = i + 1) begin
                equiv[i] <= i[LABEL_BITS-1:0];
            end

        end else begin
            // On every clock, we typically clear single-cycle signals by default.
            bram_we <= 1'b0;
            m_axis_valid <= 1'b0;
            m_axis_last <= 1'b0;

            case (state)
                // ----------------------------------------
                // IDLE: We are preparing for a new image frame.
                //       This involves clearing counters, buffers, and tables to ensure no leftovers from previous images remain.
                // ----------------------------------------
                IDLE: begin
                    pixel_idx <= '0;
                    curr_x <= '0;
                    curr_y <= '0;
                    next_label <= 1;
                    has_conflict <= 1'b0;

                    // Clear both line buffers (previous and current rows)
                    for (i = 0; i < WIDTH; i = i + 1) begin
                        prev_row[i] <= '0;
                        curr_row[i] <= '0;
                    end

                    // Reset equivalence table to self-mapping for all potential labels
                    for (i = 0; i < MAX_COMPONENTS; i = i + 1) begin
                        equiv[i] <= i[LABEL_BITS-1:0];
                    end

                    s_axis_ready <= 1'b1; // We are immediately ready to accept pixels
                    state <= PASS1_WAIT;  // Proceed to wait for our first pixel
                end

                // ----------------------------------------
                // PASS1_WAIT: In this state, we wait for a pixel data handshake from our upstream module.
                // ----------------------------------------
                PASS1_WAIT: begin
                    s_axis_ready <= 1'b1;
                    if (s_axis_valid) begin
                        curr_pixel <= s_axis_data;
                        s_axis_ready <= 1'b0; // We only read one pixel per cycle.
                        state <= PASS1_LABEL; // On next clock, start labeling this pixel.
                    end
                end

                // ----------------------------------------
                // PASS1_LABEL: Our main labeling state for the current input pixel.
                //              Here we assign a label based on neighbors, check for conflicts, and update memories.
                // ----------------------------------------
                PASS1_LABEL: begin
                    has_conflict <= 1'b0;

                    if (!curr_pixel) begin
                        // If the pixel is background, we simply assign label 0 (background label).
                        chosen_label <= '0;
                    end else begin
                        // If the pixel is foreground, we examine the 8-neighborhood to determine the smallest valid neighbor label to reuse.
                        // We use the following priority: L > NW > N > NE > create new label.
                        if (L_valid) begin
                            chosen_label <= L;
                        end else if (NW_valid) begin
                            chosen_label <= NW;
                        end else if (N_valid) begin
                            chosen_label <= N;
                        end else if (NE_valid) begin
                            chosen_label <= NE;
                        end else begin
                            // No neighbor labels are present, so we are starting a new component.
                            chosen_label <= next_label;
                            if (next_label < MAX_COMPONENTS - 1) begin
                                next_label <= next_label + 1;
                            end
                        end

                        // Now, we check for neighbor conflicts (i.e., instances where two neighbors of this pixel have different nonzero labels).
                        // This is a critical step for properly handling 8-connectivity.
                        // We start by finding the smallest non-zero neighbor label to serve as a reference.
                        min_label_tmp = '0;
                        if (L_valid) min_label_tmp = L;
                        else if (NW_valid) min_label_tmp = NW;
                        else if (N_valid) min_label_tmp = N;
                        else if (NE_valid) min_label_tmp = NE;

                        found_conflict_tmp = 1'b0;
                        other_label_tmp = '0;

                        // We check every neighbor to see if it's valid and not equal to the minimum we've chosen.
                        // If so, we've found a conflict and must record both labels for resolution.
                        if (min_label_tmp != '0) begin
                            if (NW_valid && NW != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = NW;
                            end
                            if (N_valid && N != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = N;
                            end
                            if (NE_valid && NE != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = NE;
                            end
                            if (L_valid && L != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = L;
                            end
                        end

                        if (found_conflict_tmp) begin
                            has_conflict <= 1'b1;
                            // For consistency, we always record the smaller label as conflict_label1.
                            if (min_label_tmp < other_label_tmp) begin
                                conflict_label1 <= min_label_tmp;
                                conflict_label2 <= other_label_tmp;
                            end else begin
                                conflict_label1 <= other_label_tmp;
                                conflict_label2 <= min_label_tmp;
                            end
                        end
                    end

                    // Regardless of conflict, we must write our (provisional) pixel label into BRAM and update the line buffer.
                    bram_addr_a <= pixel_idx;
                    bram_din <= curr_pixel ? (L_valid ? L : (NW_valid ? NW : (N_valid ? N : (NE_valid ? NE : next_label)))) : '0;
                    bram_we <= 1'b1;

                    // We update the line buffer for the current row so that future pixels can check their left neighbor efficiently.
                    curr_row[curr_x] <= curr_pixel ? (L_valid ? L : (NW_valid ? NW : (N_valid ? N : (NE_valid ? NE : next_label)))) : '0;

                    // If we found a conflict, we move next to the conflict resolution state;
                    // otherwise, we increment our indices to process the next pixel (including row/column wraparound).
                    if (curr_pixel && has_conflict) begin
                        state <= PASS1_CONFLICT;
                    end else begin
                        // Here, we check for end-of-frame or increment position to keep scanning.
                        if (pixel_idx == TOTAL_PIXELS - 1) begin
                            // When the last pixel is done, we initialize Pass 2 states.
                            p2_pixel_idx <= '0;
                            p2_x <= '0;
                            p2_y <= '0;
                            bram_addr_b <= '0;
                            bram_read_delay <= '0;
                            state <= PASS2_READ;
                        end else begin
                            pixel_idx <= pixel_idx + 1;
                            if (curr_x == WIDTH - 1) begin
                                // On end of row, we use our double buffer structure to advance the frame vertically and clear the row.
                                curr_x <= '0;
                                curr_y <= curr_y + 1;
                                for (i = 0; i < WIDTH; i = i + 1) begin
                                    prev_row[i] <= curr_row[i];
                                    curr_row[i] <= '0;
                                end
                            end else begin
                                curr_x <= curr_x + 1;
                            end
                            s_axis_ready <= 1'b1;
                            state <= PASS1_WAIT;
                        end
                    end
                end

                // ----------------------------------------
                // PASS1_CONFLICT: Here, we update the equivalence table (union-find).
                //                 This ensures that different labels for what should be a single component are merged.
                // ----------------------------------------
                PASS1_CONFLICT: begin
                    // We first determine the current representative root for each conflicting label.
                    // Our convention is to make the higher-numbered root point to the lower-numbered one.
                    root1_tmp = find_root(conflict_label1);
                    root2_tmp = find_root(conflict_label2);
                    
                    if (root1_tmp != root2_tmp && root1_tmp != 0 && root2_tmp != 0) begin
                        if (root1_tmp < root2_tmp) begin
                            min_root_tmp = root1_tmp;
                            max_root_tmp = root2_tmp;
                        end else begin
                            min_root_tmp = root2_tmp;
                            max_root_tmp = root1_tmp;
                        end
                        // We now update the equivalence table for the max root
                        if (max_root_tmp < MAX_COMPONENTS) begin
                            equiv[max_root_tmp] <= min_root_tmp;
                        end
                    end

                    has_conflict <= 1'b0;

                    // We then continue scanning through any remaining pixels, or move to pass 2 when complete
                    if (pixel_idx == TOTAL_PIXELS - 1) begin
                        p2_pixel_idx <= '0;
                        p2_x <= '0;
                        p2_y <= '0;
                        bram_addr_b <= '0;
                        bram_read_delay <= '0;
                        state <= PASS2_READ;
                    end else begin
                        pixel_idx <= pixel_idx + 1;
                        if (curr_x == WIDTH - 1) begin
                            curr_x <= '0;
                            curr_y <= curr_y + 1;
                            for (i = 0; i < WIDTH; i = i + 1) begin
                                prev_row[i] <= curr_row[i];
                                curr_row[i] <= '0;
                            end
                        end else begin
                            curr_x <= curr_x + 1;
                        end
                        s_axis_ready <= 1'b1;
                        state <= PASS1_WAIT;
                    end
                end

                // ----------------------------------------
                // PASS2_READ: We prepare to read a stored label from BRAM for our second pass.
                // ----------------------------------------
                PASS2_READ: begin
                    s_axis_ready <= 1'b0; // No input required during this pass.
                    bram_addr_b <= p2_pixel_idx;
                    bram_read_delay <= 2'd0; // We reset our read delay buffer.
                    state <= PASS2_WAIT;
                end

                // ----------------------------------------
                // PASS2_WAIT: Required because our BRAM has latency (here modeled as 2 cycles).
                // ----------------------------------------
                PASS2_WAIT: begin
                    if (bram_read_delay < 2'd2) begin
                        bram_read_delay <= bram_read_delay + 1;
                    end else begin
                        state <= PASS2_OUTPUT;
                    end
                end

                // ----------------------------------------
                // PASS2_OUTPUT: We produce our output, applying the final label mapping through find_root().
                // ----------------------------------------
                PASS2_OUTPUT: begin
                    raw_label_tmp = bram_dout_b;
                    
                    // We apply the equivalence mapping only for non-background pixels.
                    if (raw_label_tmp == 0) begin
                        final_label_tmp = 0;
                    end else begin
                        final_label_tmp = find_root(raw_label_tmp);
                    end

                    m_axis_valid <= 1'b1;
                    m_axis_label <= final_label_tmp;
                    m_axis_x <= p2_x;
                    m_axis_y <= p2_y;
                    m_axis_last <= (p2_pixel_idx == TOTAL_PIXELS - 1); // Signal end-of-frame when appropriate.

                    // If output was accepted, advance our pixel index and coordinate, or move to done at last pixel.
                    if (m_axis_ready || !m_axis_valid) begin
                        if (p2_pixel_idx == TOTAL_PIXELS - 1) begin
                            state <= DONE;
                        end else begin
                            p2_pixel_idx <= p2_pixel_idx + 1;
                            if (p2_x == WIDTH - 1) begin
                                p2_x <= '0;
                                p2_y <= p2_y + 1;
                            end else begin
                                p2_x <= p2_x + 1;
                            end
                            state <= PASS2_READ;
                        end
                    end
                end

                // ----------------------------------------
                // DONE: Our processing of the image is complete for this frame.
                //       We de-assert output and reinitialize for the next frame.
                // ----------------------------------------
                DONE: begin
                    m_axis_valid <= 1'b0;
                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule

`default_nettype wire

