`timescale 1ns / 1ps
`default_nettype none

module cc_calculations (
    input wire clk,
    input wire rst,
    input wire cc_pixel_valid,
    input wire [5:0] cc_pixel_label,
    input wire cc_pixel_last,
    input wire [10:0] cc_pixel_h,
    input wire [9:0] cc_pixel_v,
    output logic [10:0] cc_avg_h [3:0],
    output logic [9:0] cc_avg_v [3:0],
    output logic ccs_valid_out
);
    logic [1:0] internal_pixel_label;
    assign internal_pixel_label = cc_pixel_label[1:0] - 1;

    logic [31:0] h_pos_sum [3:0];
    logic [31:0] v_pos_sum [3:0];
    logic [31:0] pixel_tally [3:0];

    logic start_div;
    logic [3:0] calc_ver;

    logic [31:0] h_rem [3:0];
    logic [3:0]  h_valid_out;

    logic [31:0] v_rem [3:0];
    logic [3:0]  v_valid_out;

    logic cc_valid_out [4:0];

    logic [31:0] h_avg_pos [3:0];
    logic [31:0] v_avg_pos [3:0];

    always_ff @(posedge clk) begin
        if (rst) begin
            start_div <= 0;
            calc_ver <= 0;
            ccs_valid_out <= 0;
            for (integer i = 0; i < 4; i = i + 1) begin
                h_pos_sum[i] <= '0;
                v_pos_sum[i] <= '0;
                pixel_tally[i] <= '0;
                cc_valid_out[i] <= 0;
            end 
        end else begin
            if (cc_pixel_valid) begin
                h_pos_sum[internal_pixel_label] <= h_pos_sum[internal_pixel_label] + cc_pixel_h;
                v_pos_sum[internal_pixel_label] <= v_pos_sum[internal_pixel_label] + cc_pixel_v;
                pixel_tally[internal_pixel_label] <= pixel_tally[internal_pixel_label] + 1;
                if (cc_pixel_last) begin
                    start_div <= 1;
                    ccs_valid_out <= 0;
                    for (integer n = 0; n < 4; n = n + 1) begin
                        cc_avg_h[n] <= '0;
                        cc_avg_v[n] <= '0;
                    end
                end
            end else if (start_div) begin
                integer j;
                for (j = 0; j < 4; j = j + 1) begin
                    if (pixel_tally[j] > 10) begin
                        calc_ver[j] <= 1;
                    end else begin
                        j = j;
                        calc_ver[j] <= 1;
                    end
                end
                start_div <= 0;
            end
            for (integer m = 0; m < 4; m = m + 1) begin
                if (h_valid_out[m] && v_valid_out[m]) begin
                    cc_valid_out[m] <= 1;
                    h_pos_sum[m] <= 0;
                    v_pos_sum[m] <= 0;
                    pixel_tally[m] <= 0;
                    calc_ver[m] <= 0;
                end else begin
                    cc_valid_out[m] <= 0;
                end
            end
            if (cc_valid_out[0] && cc_valid_out[1] && cc_valid_out[2] && cc_valid_out[3]) begin
                ccs_valid_out <= 1;
                for (integer o = 0; o < 4; o = o + 1) begin
                    cc_avg_h[o] <= h_avg_pos[o][10:0];
                    cc_avg_v[o] <= v_avg_pos[o][9:0];
                end
                cc_valid_out[0] <= 0;
                cc_valid_out[1] <= 0;
                cc_valid_out[2] <= 0;
                cc_valid_out[3] <= 0;
            end
        end
    end

    generate
        genvar l;
        for (l = 0; l < 4; l = l + 1) begin
            divider #(
                .WIDTH(32)
            ) h_calc(
                .clk(clk),
                .rst(rst),
                .dividend(h_pos_sum[l]),
                .divisor(pixel_tally[l]),
                .data_in_valid(calc_ver[l]),
                .quotient(h_avg_pos[l]),
                .remainder(h_rem[l]),
                .data_out_valid(h_valid_out[l]),
                .error(),
                .busy()
            );

            divider #(
                .WIDTH(32)
            ) v_calc(
                .clk(clk),
                .rst(rst),
                .dividend(v_pos_sum[l]),
                .divisor(pixel_tally[l]),
                .data_in_valid(calc_ver[l]),
                .quotient(v_avg_pos[l]),
                .remainder(v_rem[l]),
                .data_out_valid(v_valid_out[l]),
                .error(),
                .busy()
            );
        end
    endgenerate 
endmodule

`default_nettype wire