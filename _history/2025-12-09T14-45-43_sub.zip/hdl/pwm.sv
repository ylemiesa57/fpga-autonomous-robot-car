
   
`timescale 1ns / 1ps
`default_nettype none

// From lab 2
module pwm (  input wire clk,
              input wire rst,
              input wire [7:0] dc_in,
              output logic sig_out);
 
    logic [31:0] count;
    logic [7:0] dc_reg;
    counter mc (.clk(clk),
                .rst(rst),
                .period(255000),
                .count(count));
    always_ff @(posedge clk) begin
        if (count >= 254000) begin
            dc_reg <= dc_in;
        end
    end
    assign sig_out = count<dc_reg; //very simple threshold check
endmodule

`default_nettype wire