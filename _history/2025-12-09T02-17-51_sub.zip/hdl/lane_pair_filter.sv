`default_nettype none

`timescale 1ns / 1ps

module lane_pair_filter #(
    parameter WIDTH = 706,
    parameter HEIGHT = 146
)(
    input wire clk, 
    input wire rst,
    
    input wire [3:0] cc_valid,
    input wire [10:0] cc_x [3:0],
    input wire [9:0] cc_y [3:0],
    input wire [31:0] cc_pixels [3:0],

    output logic [10:0] left_midpoint,
    output logic [10:0] right_midpoint,
    output logic [10:0] total_midpoint,
    output logic valid_midpoints
);

    localparam MID_H = WIDTH / 2;

    // Stage 1: pick the two largest-area blobs on each side of MID_H.
    integer left_top_idx_s1, left_bot_idx_s1;
    integer right_top_idx_s1, right_bot_idx_s1;
    integer left_top_idx_d, left_bot_idx_d;
    integer right_top_idx_d, right_bot_idx_d;

    // helper: update two-largest indices using area comparison
    function automatic void update_top2(
        input integer cand_idx,
        input integer top_in,
        input integer bot_in,
        output integer top_out,
        output integer bot_out
    );
    begin
        top_out = top_in;
        bot_out = bot_in;
        if (top_in == -1 || cc_pixels[cand_idx] > cc_pixels[top_in]) begin
            bot_out = top_in;
            top_out = cand_idx;
        end else if (bot_in == -1 || cc_pixels[cand_idx] > cc_pixels[bot_in]) begin
            bot_out = cand_idx;
        end
    end
    endfunction

    always_comb begin
        left_top_idx_d  = -1;
        left_bot_idx_d  = -1;
        right_top_idx_d = -1;
        right_bot_idx_d = -1;

        for (integer i = 0; i < 4; i = i + 1) begin
            if (cc_valid[i]) begin
                if (cc_x[i] < MID_H) begin
                    update_top2(i, left_top_idx_d, left_bot_idx_d, left_top_idx_d, left_bot_idx_d);
                end else begin
                    update_top2(i, right_top_idx_d, right_bot_idx_d, right_top_idx_d, right_bot_idx_d);
                end
            end
        end
    end

    always_ff @(posedge clk) begin
        if (rst) begin
            left_top_idx_s1  <= -1;
            left_bot_idx_s1  <= -1;
            right_top_idx_s1 <= -1;
            right_bot_idx_s1 <= -1;
        end else begin
            left_top_idx_s1  <= left_top_idx_d;
            left_bot_idx_s1  <= left_bot_idx_d;
            right_top_idx_s1 <= right_top_idx_d;
            right_bot_idx_s1 <= right_bot_idx_d;
        end
    end

    // Stage 2: midpoint math based on registered indices.
    logic [10:0] left_ccs_midpoint_s2;
    logic [10:0] right_ccs_midpoint_s2;
    logic        left_sel_s2, right_sel_s2;

    always_ff @(posedge clk) begin
        if (rst) begin
            left_ccs_midpoint_s2  <= '0;
            right_ccs_midpoint_s2 <= '0;
            total_midpoint        <= '0;
            left_midpoint         <= '0;
            right_midpoint        <= '0;
            valid_midpoints       <= 1'b0;
        end else begin
            left_ccs_midpoint_s2  <= '0;
            right_ccs_midpoint_s2 <= '0;
            total_midpoint        <= '0;
            left_midpoint         <= '0;
            right_midpoint        <= '0;
            valid_midpoints       <= 1'b0;
            left_sel_s2           <= 1'b0;
            right_sel_s2          <= 1'b0;

            // Left side midpoint: if two candidates, weight bottom heavier; otherwise take single x.
            if (left_top_idx_s1 != -1) begin
                left_sel_s2 <= 1'b1;
                if (left_bot_idx_s1 != -1) begin
                    integer top_idx, bot_idx;
                    if (cc_y[left_top_idx_s1] > cc_y[left_bot_idx_s1]) begin
                        bot_idx = left_top_idx_s1;
                        top_idx = left_bot_idx_s1;
                    end else begin
                        bot_idx = left_bot_idx_s1;
                        top_idx = left_top_idx_s1;
                    end
                    left_ccs_midpoint_s2 <= ((cc_x[bot_idx] * 3) + cc_x[top_idx]) >> 2;
                end else begin
                    left_ccs_midpoint_s2 <= cc_x[left_top_idx_s1];
                end
            end

            // Right side midpoint
            if (right_top_idx_s1 != -1) begin
                right_sel_s2 <= 1'b1;
                if (right_bot_idx_s1 != -1) begin
                    integer top_idx, bot_idx;
                    if (cc_y[right_top_idx_s1] > cc_y[right_bot_idx_s1]) begin
                        bot_idx = right_top_idx_s1;
                        top_idx = right_bot_idx_s1;
                    end else begin
                        bot_idx = right_bot_idx_s1;
                        top_idx = right_top_idx_s1;
                    end
                    right_ccs_midpoint_s2 <= ((cc_x[bot_idx] * 3) + cc_x[top_idx]) >> 2;
                end else begin
                    right_ccs_midpoint_s2 <= cc_x[right_top_idx_s1];
                end
            end

            if (left_sel_s2 && right_sel_s2) begin
                total_midpoint  <= (left_ccs_midpoint_s2 + right_ccs_midpoint_s2) >> 1;
                left_midpoint   <= left_ccs_midpoint_s2;
                right_midpoint  <= right_ccs_midpoint_s2;
                valid_midpoints <= 1'b1;
            end
        end
    end
endmodule

`default_nettype wire