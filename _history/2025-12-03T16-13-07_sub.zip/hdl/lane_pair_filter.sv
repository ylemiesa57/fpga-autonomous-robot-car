`timescale 1ns / 1ps
`default_nettype none


//   * Take the 4 blob centroids from CCL.
//   * Toss any blobs that look bogus (too small, too big, wrong side of the image).
//   * Build every possible left/right pairing, score them, and keep the best one.
//   * Do the comparison ladder in stages so timing doesn’t explode.
//   * Register the final pick so the overlay + planner see something stable for a whole frame.
// Tiny helper: given two candidate pairs, spit out the one with the better score.
// Makes the tournament tree code way cleaner.
module lane_pair_select #(
    parameter SCORE_BITS = 1,
    parameter X_BITS = 1,
    parameter Y_BITS = 1
)(
    input  wire a_valid,
    input  wire [SCORE_BITS-1:0] a_score,
    input  wire [X_BITS-1:0]     a_left_x,
    input  wire [Y_BITS-1:0]     a_left_y,
    input  wire [X_BITS-1:0]     a_right_x,
    input  wire [Y_BITS-1:0]     a_right_y,
    input  wire b_valid,
    input  wire [SCORE_BITS-1:0] b_score,
    input  wire [X_BITS-1:0]     b_left_x,
    input  wire [Y_BITS-1:0]     b_left_y,
    input  wire [X_BITS-1:0]     b_right_x,
    input  wire [Y_BITS-1:0]     b_right_y,
    output logic best_valid,
    output logic [SCORE_BITS-1:0] best_score,
    output logic [X_BITS-1:0]     best_left_x,
    output logic [Y_BITS-1:0]     best_left_y,
    output logic [X_BITS-1:0]     best_right_x,
    output logic [Y_BITS-1:0]     best_right_y
);
    always_comb begin
        // Default to “no winner” until we inspect the inputs.
        best_valid   = 1'b0;
        best_score   = {SCORE_BITS{1'b1}}; // max score == super bad
        best_left_x  = '0;
        best_left_y  = '0;
        best_right_x = '0;
        best_right_y = '0;

        // If both candidates are real, pick the smaller score.
        if (a_valid && b_valid) begin
            if (a_score <= b_score) begin
                best_valid   = 1'b1;
                best_score   = a_score;
                best_left_x  = a_left_x;
                best_left_y  = a_left_y;
                best_right_x = a_right_x;
                best_right_y = a_right_y;
            end else begin
                best_valid   = 1'b1;
                best_score   = b_score;
                best_left_x  = b_left_x;
                best_left_y  = b_left_y;
                best_right_x = b_right_x;
                best_right_y = b_right_y;
            end
        // Only A is valid ⇒ it wins by default.
        end else if (a_valid) begin
            best_valid   = 1'b1;
            best_score   = a_score;
            best_left_x  = a_left_x;
            best_left_y  = a_left_y;
            best_right_x = a_right_x;
            best_right_y = a_right_y;
        // Only B is valid ⇒ same logic.
        end else if (b_valid) begin
            best_valid   = 1'b1;
            best_score   = b_score;
            best_left_x  = b_left_x;
            best_left_y  = b_left_y;
            best_right_x = b_right_x;
            best_right_y = b_right_y;
        end
    end
endmodule

module lane_pair_filter #(
    // Student knobs: tweak these to match your BEV resolution + blob heuristics.
    parameter WIDTH = 177,                // BEV width (downsampled ROI width)
    parameter HEIGHT = 36,                // BEV height
    parameter CENTER_X = WIDTH / 2,       // Rough midline that separates “left” and “right” blobs
    parameter MIN_AREA = 32,              // Throw away tiny blobs
    parameter MAX_AREA = WIDTH * HEIGHT,  // ...and absurdly huge ones
    parameter MIN_LANE_WIDTH = WIDTH / 6, // Acceptable gap between left/right blobs
    parameter MAX_LANE_WIDTH = WIDTH,
    parameter MAX_Y_DELTA = HEIGHT / 4    // How much vertical misalignment we tolerate
)(
    input wire clk,
    input wire rst,
    input wire [31:0] blob_x0,
    input wire [31:0] blob_x1,
    input wire [31:0] blob_x2,
    input wire [31:0] blob_x3,
    input wire [31:0] blob_y0,
    input wire [31:0] blob_y1,
    input wire [31:0] blob_y2,
    input wire [31:0] blob_y3,
    input wire [31:0] blob_area0,
    input wire [31:0] blob_area1,
    input wire [31:0] blob_area2,
    input wire [31:0] blob_area3,
    input wire [3:0]  blob_valid,
    output logic lanes_valid,
    output logic [31:0] lane_left_x,
    output logic [31:0] lane_left_y,
    output logic [31:0] lane_right_x,
    output logic [31:0] lane_right_y,
    output logic [3:0]  active_mask
);

    // Derived constants: mostly “how many bits do we really need?” math.
    parameter NUM_BLOBS = 4;
    parameter NUM_PAIRS = NUM_BLOBS * NUM_BLOBS;
    parameter X_BITS = (WIDTH <= 1) ? 1 : $clog2(WIDTH);
    parameter Y_BITS = (HEIGHT <= 1) ? 1 : $clog2(HEIGHT);
    parameter GAP_BITS = X_BITS;
    parameter DELTA_BITS = Y_BITS;
    parameter SCORE_BITS = GAP_BITS + DELTA_BITS; // concatenate gap + delta
    parameter GAP_RANGE = (1 << GAP_BITS);
    parameter DELTA_RANGE = (1 << DELTA_BITS);
    parameter MIN_LANE_WIDTH_CLAMP = (MIN_LANE_WIDTH < 0) ? 0 :
                                     ((MIN_LANE_WIDTH >= GAP_RANGE) ? (GAP_RANGE - 1) : MIN_LANE_WIDTH);
    parameter MAX_LANE_WIDTH_CLAMP = (MAX_LANE_WIDTH < 0) ? 0 :
                                     ((MAX_LANE_WIDTH >= GAP_RANGE) ? (GAP_RANGE - 1) : MAX_LANE_WIDTH);
    parameter MAX_Y_DELTA_CLAMP = (MAX_Y_DELTA < 0) ? 0 :
                                  ((MAX_Y_DELTA >= DELTA_RANGE) ? (DELTA_RANGE - 1) : MAX_Y_DELTA);
    parameter logic [GAP_BITS-1:0]   MIN_LANE_WIDTH_N = MIN_LANE_WIDTH_CLAMP[GAP_BITS-1:0];
    parameter logic [GAP_BITS-1:0]   MAX_LANE_WIDTH_N = MAX_LANE_WIDTH_CLAMP[GAP_BITS-1:0];
    parameter logic [DELTA_BITS-1:0] MAX_Y_DELTA_N    = MAX_Y_DELTA_CLAMP[DELTA_BITS-1:0];
    parameter logic [X_BITS-1:0]     CENTER_X_N       = CENTER_X[X_BITS-1:0];
    parameter X_PAD = (32 > X_BITS) ? (32 - X_BITS) : 0; // pad when we widen to 32-bit outputs
    parameter Y_PAD = (32 > Y_BITS) ? (32 - Y_BITS) : 0;
    parameter STAGE1_COUNT = NUM_PAIRS / 2;
    parameter STAGE2_COUNT = STAGE1_COUNT / 2;
    parameter STAGE3_COUNT = STAGE2_COUNT / 2;

    // Convenience arrays (makes for-loops tolerable).
    logic [31:0] blob_x_arr [0:NUM_BLOBS-1];
    logic [31:0] blob_y_arr [0:NUM_BLOBS-1];
    logic [31:0] blob_area_arr [0:NUM_BLOBS-1];
    logic        size_ok_arr [0:NUM_BLOBS-1];
    logic        left_mask_arr [0:NUM_BLOBS-1];
    logic        right_mask_arr [0:NUM_BLOBS-1];
    logic [X_BITS-1:0] blob_x_compact [0:NUM_BLOBS-1];
    logic [Y_BITS-1:0] blob_y_compact [0:NUM_BLOBS-1];

    // Combinational and registered versions of “every possible pair.”
    logic pair_valid_comb      [0:NUM_PAIRS-1];
    logic [SCORE_BITS-1:0] pair_score_comb   [0:NUM_PAIRS-1];
    logic [X_BITS-1:0] pair_left_x_comb     [0:NUM_PAIRS-1];
    logic [Y_BITS-1:0] pair_left_y_comb     [0:NUM_PAIRS-1];
    logic [X_BITS-1:0] pair_right_x_comb    [0:NUM_PAIRS-1];
    logic [Y_BITS-1:0] pair_right_y_comb    [0:NUM_PAIRS-1];

    logic pair_valid_q      [0:NUM_PAIRS-1];
    logic [SCORE_BITS-1:0] pair_score_q   [0:NUM_PAIRS-1];
    logic [X_BITS-1:0] pair_left_x_q     [0:NUM_PAIRS-1];
    logic [Y_BITS-1:0] pair_left_y_q     [0:NUM_PAIRS-1];
    logic [X_BITS-1:0] pair_right_x_q    [0:NUM_PAIRS-1];
    logic [Y_BITS-1:0] pair_right_y_q    [0:NUM_PAIRS-1];
    logic [NUM_BLOBS-1:0] size_ok_q;

    // Tournament tree scratchpads (3 layers max because 4 blobs ⇒ 16 pairs).
    logic stage1_valid      [0:STAGE1_COUNT-1];
    logic [SCORE_BITS-1:0] stage1_score    [0:STAGE1_COUNT-1];
    logic [X_BITS-1:0] stage1_left_x      [0:STAGE1_COUNT-1];
    logic [Y_BITS-1:0] stage1_left_y      [0:STAGE1_COUNT-1];
    logic [X_BITS-1:0] stage1_right_x     [0:STAGE1_COUNT-1];
    logic [Y_BITS-1:0] stage1_right_y     [0:STAGE1_COUNT-1];

    logic stage2_valid      [0:STAGE2_COUNT-1];
    logic [SCORE_BITS-1:0] stage2_score    [0:STAGE2_COUNT-1];
    logic [X_BITS-1:0] stage2_left_x      [0:STAGE2_COUNT-1];
    logic [Y_BITS-1:0] stage2_left_y      [0:STAGE2_COUNT-1];
    logic [X_BITS-1:0] stage2_right_x     [0:STAGE2_COUNT-1];
    logic [Y_BITS-1:0] stage2_right_y     [0:STAGE2_COUNT-1];

    logic stage3_valid      [0:STAGE3_COUNT-1];
    logic [SCORE_BITS-1:0] stage3_score    [0:STAGE3_COUNT-1];
    logic [X_BITS-1:0] stage3_left_x      [0:STAGE3_COUNT-1];
    logic [Y_BITS-1:0] stage3_left_y      [0:STAGE3_COUNT-1];
    logic [X_BITS-1:0] stage3_right_x     [0:STAGE3_COUNT-1];
    logic [Y_BITS-1:0] stage3_right_y     [0:STAGE3_COUNT-1];

    logic best_valid;
    logic [SCORE_BITS-1:0] best_score;
    logic [X_BITS-1:0] best_left_x;
    logic [Y_BITS-1:0] best_left_y;
    logic [X_BITS-1:0] best_right_x;
    logic [Y_BITS-1:0] best_right_y;

    // Flatten the incoming bus-y signals into arrays so we can loop easily.
    assign blob_x_arr[0] = blob_x0;
    assign blob_x_arr[1] = blob_x1;
    assign blob_x_arr[2] = blob_x2;
    assign blob_x_arr[3] = blob_x3;

    assign blob_y_arr[0] = blob_y0;
    assign blob_y_arr[1] = blob_y1;
    assign blob_y_arr[2] = blob_y2;
    assign blob_y_arr[3] = blob_y3;

    assign blob_area_arr[0] = blob_area0;
    assign blob_area_arr[1] = blob_area1;
    assign blob_area_arr[2] = blob_area2;
    assign blob_area_arr[3] = blob_area3;

    genvar blob_idx;
    generate
        for (blob_idx = 0; blob_idx < NUM_BLOBS; blob_idx = blob_idx + 1) begin : gen_blob_slices
            // Chop 32-bit centroids down to just the bits we need.
            assign blob_x_compact[blob_idx] = blob_x_arr[blob_idx][X_BITS-1:0];
            assign blob_y_compact[blob_idx] = blob_y_arr[blob_idx][Y_BITS-1:0];
        end
    endgenerate

    // Combinational brain: figure out which blobs are usable, then build/scored every left/right combo.
    always_comb begin
        integer idx;
        integer i_idx;
        integer j_idx;
        integer pair_idx;
        logic [GAP_BITS:0]   pair_gap_ext;
        logic [DELTA_BITS:0] pair_y_delta_ext;
        logic [GAP_BITS-1:0] pair_gap_local;
        logic [DELTA_BITS-1:0] pair_y_delta_local;

        // Step 1: decide which blobs are even worth considering.
        for (idx = 0; idx < NUM_BLOBS; idx = idx + 1) begin
            // size_ok_arr[idx] = “is this blob both valid and within our area limits?”
            size_ok_arr[idx]  = blob_valid[idx] &&
                                (blob_area_arr[idx] >= MIN_AREA) &&
                                (blob_area_arr[idx] <= MAX_AREA);
            // Remember which side of the road this blob lives on.
            left_mask_arr[idx]  = size_ok_arr[idx] && (blob_x_compact[idx] < CENTER_X_N);
            right_mask_arr[idx] = size_ok_arr[idx] && (blob_x_compact[idx] >= CENTER_X_N);
        end

        // Step 2: clear the pair bookkeeping.
        for (idx = 0; idx < NUM_PAIRS; idx = idx + 1) begin
            pair_valid_comb[idx]   = 1'b0;
            pair_score_comb[idx]   = {SCORE_BITS{1'b1}};
            pair_left_x_comb[idx]  = '0;
            pair_left_y_comb[idx]  = '0;
            pair_right_x_comb[idx] = '0;
            pair_right_y_comb[idx] = '0;
        end

        // Step 3: brute-force every (left,right) combo.
        for (i_idx = 0; i_idx < NUM_BLOBS; i_idx = i_idx + 1) begin
            for (j_idx = 0; j_idx < NUM_BLOBS; j_idx = j_idx + 1) begin
                pair_idx = (i_idx * NUM_BLOBS) + j_idx;
                pair_gap_ext       = '0;
                pair_y_delta_ext   = '0;
                pair_gap_local     = '0;
                pair_y_delta_local = '0;

                // Only keep pairs where i=left, j=right, and the right blob is actually to the right.
                if (left_mask_arr[i_idx] && right_mask_arr[j_idx] &&
                    (blob_x_compact[j_idx] > blob_x_compact[i_idx])) begin
                    pair_gap_ext = {1'b0, blob_x_compact[j_idx]} - {1'b0, blob_x_compact[i_idx]};
                    pair_gap_local = pair_gap_ext[GAP_BITS-1:0];
                    if ((pair_gap_local >= MIN_LANE_WIDTH_N) && (pair_gap_local <= MAX_LANE_WIDTH_N)) begin
                        if (blob_y_compact[i_idx] >= blob_y_compact[j_idx]) begin
                            pair_y_delta_ext = {1'b0, blob_y_compact[i_idx]} - {1'b0, blob_y_compact[j_idx]};
                        end else begin
                            pair_y_delta_ext = {1'b0, blob_y_compact[j_idx]} - {1'b0, blob_y_compact[i_idx]};
                        end
                        pair_y_delta_local = pair_y_delta_ext[DELTA_BITS-1:0];
                        if (pair_y_delta_local <= MAX_Y_DELTA_N) begin // lanes shouldn’t have crazy slope difference
                            pair_valid_comb[pair_idx]   = 1'b1;
                            pair_score_comb[pair_idx]   = {pair_y_delta_local, pair_gap_local}; // lower delta/gap = better score
                            pair_left_x_comb[pair_idx]  = blob_x_compact[i_idx];
                            pair_left_y_comb[pair_idx]  = blob_y_compact[i_idx];
                            pair_right_x_comb[pair_idx] = blob_x_compact[j_idx];
                            pair_right_y_comb[pair_idx] = blob_y_compact[j_idx];
                        end
                    end
                end
            end
        end
    end

    // Pipeline register: capture the combinational results so the tournament tree sees clean data.
    always_ff @(posedge clk) begin
        integer idx;

        if (rst) begin
            // Reset everything to harmless defaults.
            for (idx = 0; idx < NUM_PAIRS; idx = idx + 1) begin
                pair_valid_q[idx]   <= 1'b0;
                pair_score_q[idx]   <= {SCORE_BITS{1'b1}};
                pair_left_x_q[idx]  <= '0;
                pair_left_y_q[idx]  <= '0;
                pair_right_x_q[idx] <= '0;
                pair_right_y_q[idx] <= '0;
            end
            size_ok_q <= '0;
        end else begin
            // Normal operation: just latch the combinational values.
            for (idx = 0; idx < NUM_PAIRS; idx = idx + 1) begin
                pair_valid_q[idx]   <= pair_valid_comb[idx];
                pair_score_q[idx]   <= pair_score_comb[idx];
                pair_left_x_q[idx]  <= pair_left_x_comb[idx];
                pair_left_y_q[idx]  <= pair_left_y_comb[idx];
                pair_right_x_q[idx] <= pair_right_x_comb[idx];
                pair_right_y_q[idx] <= pair_right_y_comb[idx];
            end
            for (idx = 0; idx < NUM_BLOBS; idx = idx + 1) begin
                size_ok_q[idx] <= size_ok_arr[idx];
            end
        end
    end

    genvar g_stage1, g_stage2, g_stage3;
    // Tournament stage 1: compare pairs in chunks of two.
    generate
        if (STAGE1_COUNT > 0) begin : stage1_block
            for (g_stage1 = 0; g_stage1 < STAGE1_COUNT; g_stage1 = g_stage1 + 1) begin : gen_stage1
                lane_pair_select #(
                    .SCORE_BITS(SCORE_BITS),
                    .X_BITS(X_BITS),
                    .Y_BITS(Y_BITS)
                ) stage1_sel (
                    .a_valid  (pair_valid_q[2 * g_stage1]),
                    .a_score  (pair_score_q[2 * g_stage1]),
                    .a_left_x (pair_left_x_q[2 * g_stage1]),
                    .a_left_y (pair_left_y_q[2 * g_stage1]),
                    .a_right_x(pair_right_x_q[2 * g_stage1]),
                    .a_right_y(pair_right_y_q[2 * g_stage1]),
                    .b_valid  (pair_valid_q[(2 * g_stage1) + 1]),
                    .b_score  (pair_score_q[(2 * g_stage1) + 1]),
                    .b_left_x (pair_left_x_q[(2 * g_stage1) + 1]),
                    .b_left_y (pair_left_y_q[(2 * g_stage1) + 1]),
                    .b_right_x(pair_right_x_q[(2 * g_stage1) + 1]),
                    .b_right_y(pair_right_y_q[(2 * g_stage1) + 1]),
                    .best_valid  (stage1_valid[g_stage1]),
                    .best_score  (stage1_score[g_stage1]),
                    .best_left_x (stage1_left_x[g_stage1]),
                    .best_left_y (stage1_left_y[g_stage1]),
                    .best_right_x(stage1_right_x[g_stage1]),
                    .best_right_y(stage1_right_y[g_stage1])
                );
            end
        end
    endgenerate

    // Stage 2: compare the winners from stage 1.
    generate
        if (STAGE2_COUNT > 0) begin : stage2_block
            for (g_stage2 = 0; g_stage2 < STAGE2_COUNT; g_stage2 = g_stage2 + 1) begin : gen_stage2
                lane_pair_select #(
                    .SCORE_BITS(SCORE_BITS),
                    .X_BITS(X_BITS),
                    .Y_BITS(Y_BITS)
                ) stage2_sel (
                    .a_valid  (stage1_valid[2 * g_stage2]),
                    .a_score  (stage1_score[2 * g_stage2]),
                    .a_left_x (stage1_left_x[2 * g_stage2]),
                    .a_left_y (stage1_left_y[2 * g_stage2]),
                    .a_right_x(stage1_right_x[2 * g_stage2]),
                    .a_right_y(stage1_right_y[2 * g_stage2]),
                    .b_valid  (stage1_valid[(2 * g_stage2) + 1]),
                    .b_score  (stage1_score[(2 * g_stage2) + 1]),
                    .b_left_x (stage1_left_x[(2 * g_stage2) + 1]),
                    .b_left_y (stage1_left_y[(2 * g_stage2) + 1]),
                    .b_right_x(stage1_right_x[(2 * g_stage2) + 1]),
                    .b_right_y(stage1_right_y[(2 * g_stage2) + 1]),
                    .best_valid  (stage2_valid[g_stage2]),
                    .best_score  (stage2_score[g_stage2]),
                    .best_left_x (stage2_left_x[g_stage2]),
                    .best_left_y (stage2_left_y[g_stage2]),
                    .best_right_x(stage2_right_x[g_stage2]),
                    .best_right_y(stage2_right_y[g_stage2])
                );
            end
        end
    endgenerate

    // Stage 3: final four (or fewer) showdown.
    generate
        if (STAGE3_COUNT > 0) begin : stage3_block
            for (g_stage3 = 0; g_stage3 < STAGE3_COUNT; g_stage3 = g_stage3 + 1) begin : gen_stage3
                lane_pair_select #(
                    .SCORE_BITS(SCORE_BITS),
                    .X_BITS(X_BITS),
                    .Y_BITS(Y_BITS)
                ) stage3_sel (
                    .a_valid  (stage2_valid[2 * g_stage3]),
                    .a_score  (stage2_score[2 * g_stage3]),
                    .a_left_x (stage2_left_x[2 * g_stage3]),
                    .a_left_y (stage2_left_y[2 * g_stage3]),
                    .a_right_x(stage2_right_x[2 * g_stage3]),
                    .a_right_y(stage2_right_y[2 * g_stage3]),
                    .b_valid  (stage2_valid[(2 * g_stage3) + 1]),
                    .b_score  (stage2_score[(2 * g_stage3) + 1]),
                    .b_left_x (stage2_left_x[(2 * g_stage3) + 1]),
                    .b_left_y (stage2_left_y[(2 * g_stage3) + 1]),
                    .b_right_x(stage2_right_x[(2 * g_stage3) + 1]),
                    .b_right_y(stage2_right_y[(2 * g_stage3) + 1]),
                    .best_valid  (stage3_valid[g_stage3]),
                    .best_score  (stage3_score[g_stage3]),
                    .best_left_x (stage3_left_x[g_stage3]),
                    .best_left_y (stage3_left_y[g_stage3]),
                    .best_right_x(stage3_right_x[g_stage3]),
                    .best_right_y(stage3_right_y[g_stage3])
                );
            end
        end
    endgenerate

    // Final mux: if there’s only one stage3 entry, wire it straight through; otherwise compare the top two.
    generate
        if (STAGE3_COUNT == 1) begin : best_single_stage
            assign best_valid   = stage3_valid[0];
            assign best_score   = stage3_score[0];
            assign best_left_x  = stage3_left_x[0];
            assign best_left_y  = stage3_left_y[0];
            assign best_right_x = stage3_right_x[0];
            assign best_right_y = stage3_right_y[0];
        end else begin : best_compare_stage
            lane_pair_select #(
                .SCORE_BITS(SCORE_BITS),
                .X_BITS(X_BITS),
                .Y_BITS(Y_BITS)
            ) best_sel (
                .a_valid  (stage3_valid[0]),
                .a_score  (stage3_score[0]),
                .a_left_x (stage3_left_x[0]),
                .a_left_y (stage3_left_y[0]),
                .a_right_x(stage3_right_x[0]),
                .a_right_y(stage3_right_y[0]),
                .b_valid  (stage3_valid[1]),
                .b_score  (stage3_score[1]),
                .b_left_x (stage3_left_x[1]),
                .b_left_y (stage3_left_y[1]),
                .b_right_x(stage3_right_x[1]),
                .b_right_y(stage3_right_y[1]),
                .best_valid  (best_valid),
                .best_score  (best_score),
                .best_left_x (best_left_x),
                .best_left_y (best_left_y),
                .best_right_x(best_right_x),
                .best_right_y(best_right_y)
            );
        end
    endgenerate

    // Output register: make the winning pair sticky for a full frame and expose some debug bits.
    always_ff @(posedge clk) begin
        if (rst) begin
            lanes_valid   <= 1'b0;
            lane_left_x   <= '0;
            lane_left_y   <= '0;
            lane_right_x  <= '0;
            lane_right_y  <= '0;
            active_mask   <= '0;
        end else begin
            // Handy LED/debug output: which blob slots were actually usable.
            active_mask <= {size_ok_q[3], size_ok_q[2], size_ok_q[1], size_ok_q[0]};
            if (best_valid) begin
                lanes_valid  <= 1'b1;
                lane_left_x  <= {{X_PAD{1'b0}}, best_left_x};
                lane_left_y  <= {{Y_PAD{1'b0}}, best_left_y};
                lane_right_x <= {{X_PAD{1'b0}}, best_right_x};
                lane_right_y <= {{Y_PAD{1'b0}}, best_right_y};
            end else begin
                // No decent pair this frame: drive zeros so downstream modules know to chill.
                lanes_valid  <= 1'b0;
                lane_left_x  <= '0;
                lane_left_y  <= '0;
                lane_right_x <= '0;
                lane_right_y <= '0;
            end
        end
    end

endmodule

`default_nettype wire
