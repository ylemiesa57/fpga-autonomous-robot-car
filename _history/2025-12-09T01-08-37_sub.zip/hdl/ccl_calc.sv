`default_nettype none

`timescale 1ns / 1ps

module cc_calculations #(
    parameter WIDTH = 708,
    parameter HEIGHT = 146
)(
    input wire clk,
    input wire rst,
    
    // Stream from CCL
    input wire cc_pixel_valid,
    input wire [11:0] cc_pixel_label, 
    // just to be safe we can have as many blobs as we want on our screen! but we only have 4 lane markers
    // so we will only consider 4 blobs on our screen at a time.
    input wire cc_pixel_last,
    input wire [8:0] cc_pixel_h,
    input wire [7:0] cc_pixel_v,
    // Outputs to Lane Pairing
    output logic [10:0] h_avg_pos [0:1],
    output logic [9:0] v_avg_pos [0:1],
    output logic [31:0] blob_area [0:1],
    output logic [1:0]  cc_valid_out
);

    logic [0:0] internal_pixel_label; // only 0 or 1 now (label 1 or 2)
    assign internal_pixel_label = cc_pixel_label[0] ? 1'b0 : 1'b1; // Wait, label 1->0, label 2->1.
    // cc_pixel_label is 12 bits. 
    // If labels are 1 and 2:
    // 1 -> 00...01.  1-1 = 0.
    // 2 -> 00...10.  2-1 = 1.
    // So internal_pixel_label = cc_pixel_label[0] is not quite right if we just subtract.
    // Let's keep subtraction logic but resize.

    // cc_pixel_label - 1. 
    // If label=1, idx=0. If label=2, idx=1.
    
    logic [31:0] h_pos_sum   [0:1];
    logic [31:0] v_pos_sum   [0:1];
    logic [31:0] pixel_tally [0:1];
    logic [1:0]  div_in_valid;
    logic [1:0]  div_h_out_valid;
    logic [1:0]  div_v_out_valid;
    logic [31:0] div_h_quotient [0:1];
    logic [31:0] div_v_quotient [0:1];
    logic [10:0] h_result       [0:1];
    logic [9:0] v_result       [0:1];
    logic [1:0]  h_ready;
    logic [1:0]  v_ready;

    integer i;

    always_ff @(posedge clk) begin
        if (rst) begin
            div_in_valid <= 0;
            cc_valid_out <= 0;
            h_ready <= 0;
            v_ready <= 0;
            for (i = 0; i < 2; i = i + 1) begin
                h_pos_sum[i] <= 0;
                v_pos_sum[i] <= 0;
                pixel_tally[i] <= 0;
                h_avg_pos[i] <= 0;
                v_avg_pos[i] <= 0;
                blob_area[i] <= 0;
                h_result[i] <= 0;
                v_result[i] <= 0;
            end
        end else begin
            // 1. We accumulate centroid sums while the frame is active.
            if (cc_pixel_valid) begin
                if (cc_pixel_label >= 1 && cc_pixel_label <= 2) begin
                    h_pos_sum[cc_pixel_label[0] ? 0 : 1] <= h_pos_sum[cc_pixel_label[0] ? 0 : 1] + cc_pixel_h;
                    // Wait, label 1 is odd (bit 0 is 1), label 2 is even (bit 0 is 0).
                    // So label 1 -> idx 0. label 2 -> idx 1.
                    // If label=1 (binary 01), bit 0 is 1. idx should be 0.
                    // If label=2 (binary 10), bit 0 is 0. idx should be 1.
                    // So idx = ~cc_pixel_label[0]. 
                    // Let's just use subtraction for clarity.
                    h_pos_sum[cc_pixel_label-1] <= h_pos_sum[cc_pixel_label-1] + cc_pixel_h;
                    v_pos_sum[cc_pixel_label-1] <= v_pos_sum[cc_pixel_label-1] + cc_pixel_v;
                    pixel_tally[cc_pixel_label-1] <= pixel_tally[cc_pixel_label-1] + 1;
                end
            end

            // 2. At end-of-frame we only kick off dividers for blobs that actually saw pixels.
            div_in_valid <= '0;
            if (cc_pixel_last) begin
                for (i = 0; i < 2; i = i + 1) begin
                    div_in_valid[i] <= (pixel_tally[i] > 10);
                end
            end

            // 3. We add pipelining to the divider results and publish valid blobs once both averages are ready.
            for (i = 0; i < 2; i = i + 1) begin
                if (div_h_out_valid[i]) begin
                    h_result[i] <= div_h_quotient[i];
                    h_ready[i]  <= 1'b1;
                end
                if (div_v_out_valid[i]) begin
                    v_result[i] <= div_v_quotient[i];
                    v_ready[i]  <= 1'b1;
                end
                if (h_ready[i] && v_ready[i]) begin
                    if (pixel_tally[i] > 5) begin
                        h_avg_pos[i] <= h_result[i];
                        v_avg_pos[i] <= v_result[i];
                        blob_area[i] <= pixel_tally[i];
                        cc_valid_out[i] <= 1;
                    end else begin
                        cc_valid_out[i] <= 0;
                        blob_area[i] <= 0;
                    end
                    // We clear the accumulators so the next frame starts fresh.
                    h_pos_sum[i] <= 0;
                    v_pos_sum[i] <= 0;
                    pixel_tally[i] <= 0;
                    h_ready[i] <= 0;
                    v_ready[i] <= 0;
                end
            end
        end
    end

    // We keep two divider pairs running in parallel.
    generate
        genvar j;
        for (j = 0; j < 2; j = j + 1) begin : gen_divs
            divider #( .WIDTH(32) ) h_calc (
                .clk(clk),
                .rst(rst),
                .dividend(h_pos_sum[j]),
                .divisor(pixel_tally[j]),
                .data_in_valid(div_in_valid[j]),
                .quotient(div_h_quotient[j]),
                .remainder(),
                .data_out_valid(div_h_out_valid[j]),
                .error(),
                .busy()
            );

            divider #( .WIDTH(32) ) v_calc (
                .clk(clk),
                .rst(rst),
                .dividend(v_pos_sum[j]),
                .divisor(pixel_tally[j]),
                .data_in_valid(div_in_valid[j]),
                .quotient(div_v_quotient[j]),
                .remainder(),
                .data_out_valid(div_v_out_valid[j]),
                .error(),
                .busy()
            );
        end
    endgenerate

endmodule

`default_nettype wire