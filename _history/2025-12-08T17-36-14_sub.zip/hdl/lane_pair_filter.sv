`default_nettype none

`timescale 1ns / 1ps

module lane_pair_filter #(
    parameter WIDTH = 706,
    parameter HEIGHT = 146
)(
    input wire clk, 
    input wire rst,
    
    input wire [3:0] cc_valid,
    input wire [10:0] cc_x [3:0],
    input wire [9:0] cc_y [3:0],
    input wire [31:0] cc_pixels [3:0],

    output logic [10:0] left_midpoint,
    output logic [10:0] right_midpoint,
    output logic [10:0] total_midpoint,
    output logic valid_midpoints
);

    localparam MID_H = WIDTH / 2; // does this division take extensive time to run?

    // Stage 1: select candidates (registered).
    integer left_top_idx_s1;
    integer left_bot_idx_s1;
    integer right_top_idx_s1;
    integer right_bot_idx_s1;

    always_ff @(posedge clk) begin
        if (rst) begin
            left_top_idx_s1  <= -1;
            left_bot_idx_s1  <= -1;
            right_top_idx_s1 <= -1;
            right_bot_idx_s1 <= -1;
        end else begin
            left_top_idx_s1  <= -1;
            left_bot_idx_s1  <= -1;
            right_top_idx_s1 <= -1;
            right_bot_idx_s1 <= -1;

            // select up to two blobs per side, prefer larger y as "bottom"
            for (integer i = 0; i < 4; i = i + 1) begin
                if (cc_valid[i]) begin
                    if (cc_x[i] < MID_H) begin
                        if (left_top_idx_s1 == -1) begin
                            left_top_idx_s1 = i;
                        end else if (left_bot_idx_s1 == -1) begin
                            if (cc_y[i] > cc_y[left_top_idx_s1]) begin
                                left_bot_idx_s1 = left_top_idx_s1;
                                left_top_idx_s1 = i;
                            end else begin
                                left_bot_idx_s1 = i;
                            end
                        end else if (cc_y[i] > cc_y[left_top_idx_s1]) begin
                            left_bot_idx_s1 = left_top_idx_s1;
                            left_top_idx_s1 = i;
                        end else if (cc_y[i] > cc_y[left_bot_idx_s1]) begin
                            left_bot_idx_s1 = i;
                        end
                    end else begin
                        if (right_top_idx_s1 == -1) begin
                            right_top_idx_s1 = i;
                        end else if (right_bot_idx_s1 == -1) begin
                            if (cc_y[i] > cc_y[right_top_idx_s1]) begin
                                right_bot_idx_s1 = right_top_idx_s1;
                                right_top_idx_s1 = i;
                            end else begin
                                right_bot_idx_s1 = i;
                            end
                        end else if (cc_y[i] > cc_y[right_top_idx_s1]) begin
                            right_bot_idx_s1 = right_top_idx_s1;
                            right_top_idx_s1 = i;
                        end else if (cc_y[i] > cc_y[right_bot_idx_s1]) begin
                            right_bot_idx_s1 = i;
                        end
                    end
                end
            end
        end
    end

    // Stage 2: midpoint math based on registered indices.
    logic [10:0] left_ccs_midpoint_s2;
    logic [10:0] right_ccs_midpoint_s2;

    always_ff @(posedge clk) begin
        if (rst) begin
            left_ccs_midpoint_s2  <= '0;
            right_ccs_midpoint_s2 <= '0;
            total_midpoint        <= '0;
            left_midpoint         <= '0;
            right_midpoint        <= '0;
            valid_midpoints       <= 1'b0;
        end else begin
            left_ccs_midpoint_s2  <= '0;
            right_ccs_midpoint_s2 <= '0;
            total_midpoint        <= '0;
            left_midpoint         <= '0;
            right_midpoint        <= '0;
            valid_midpoints       <= 1'b0;

            if (left_top_idx_s1 != -1 && left_bot_idx_s1 != -1) begin
                left_ccs_midpoint_s2 <= ((cc_x[left_bot_idx_s1] * 3) + cc_x[left_top_idx_s1]) >> 2;
            end else if (left_top_idx_s1 != -1) begin
                left_ccs_midpoint_s2 <= cc_x[left_top_idx_s1];
            end

            if (right_top_idx_s1 != -1 && right_bot_idx_s1 != -1) begin
                right_ccs_midpoint_s2 <= ((cc_x[right_bot_idx_s1] * 3) + cc_x[right_top_idx_s1]) >> 2;
            end else if (right_top_idx_s1 != -1) begin
                right_ccs_midpoint_s2 <= cc_x[right_top_idx_s1];
            end

            if (left_ccs_midpoint_s2 != 0 && right_ccs_midpoint_s2 != 0) begin
                total_midpoint  <= (left_ccs_midpoint_s2 + right_ccs_midpoint_s2) >> 1;
                left_midpoint   <= left_ccs_midpoint_s2;
                right_midpoint  <= right_ccs_midpoint_s2;
                valid_midpoints <= 1'b1;
            end
        end
    end
endmodule

`default_nettype wire