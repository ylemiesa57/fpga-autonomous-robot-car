module cocotb_iverilog_dump();
initial begin
    $dumpfile("/Users/tyler/MIT/Classes/6.2050/fa25-6205-team36/sim/sim_build/region_of_interest.fst");
    $dumpvars(0, region_of_interest);
end
endmodule
