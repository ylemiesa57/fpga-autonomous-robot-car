`timescale 1ns / 1ps
`default_nettype none

// CLE-style 8-Connectivity Connected Component Labeling
// ======================================================
// Based on the CLE algorithm with adaptations for:
// - Parameterized image dimensions
// - AXI stream interfaces
// - 8-connectivity neighbor checking
//
// Memory efficient: Only uses 2 line buffers + small equivalence table
// Two-pass approach:
//   Pass 1: Label pixels, detect conflicts, build equivalence table, store in BRAM
//   Pass 2: Read BRAM, apply equivalence mapping, stream output

module cle_module_8conn #(
    parameter int WIDTH = 177,
    parameter int HEIGHT = 36,
    parameter int LABEL_BITS = 12,
    parameter int MAX_COMPONENTS = 16   // Max distinct blobs expected
)(
    input wire clk,
    input wire rst,

    // Input Stream (binary pixels)
    input wire s_axis_valid,
    input wire s_axis_data,             // 1 = foreground, 0 = background
    output logic s_axis_ready,

    // Output Stream (labeled pixels with coordinates)
    output logic m_axis_valid,
    output logic [LABEL_BITS-1:0] m_axis_label,
    output logic [$clog2(WIDTH)-1:0] m_axis_x,
    output logic [$clog2(HEIGHT)-1:0] m_axis_y,
    output logic m_axis_last,
    input wire m_axis_ready
);

    // --- Parameters ---
    localparam TOTAL_PIXELS = WIDTH * HEIGHT;
    localparam ADDR_BITS = $clog2(TOTAL_PIXELS);
    localparam X_BITS = $clog2(WIDTH);
    localparam Y_BITS = $clog2(HEIGHT);
    localparam EQUIV_BITS = $clog2(MAX_COMPONENTS + 1);

    // --- State Machine ---
    typedef enum logic [2:0] {
        IDLE,
        PASS1_WAIT,         // Wait for input pixel
        PASS1_LABEL,        // Label current pixel
        PASS1_CONFLICT,     // Resolve conflict in equiv table
        PASS2_READ,         // Read from BRAM
        PASS2_WAIT,         // Wait for BRAM data
        PASS2_OUTPUT,       // Output labeled pixel
        DONE
    } state_t;

    state_t state;

    // --- BRAM for storing Pass 1 labels ---
    // Stores provisional labels indexed by pixel address
    logic [ADDR_BITS-1:0] bram_addr_a, bram_addr_b;
    logic [LABEL_BITS-1:0] bram_din, bram_dout_a, bram_dout_b;
    logic bram_we;

    xilinx_true_dual_port_read_first_1_clock_ram #(
        .RAM_WIDTH(LABEL_BITS),
        .RAM_DEPTH(TOTAL_PIXELS)
    ) label_bram (
        .addra(bram_addr_a),
        .clka(clk),
        .wea(bram_we),
        .dina(bram_din),
        .ena(1'b1),
        .rsta(rst),
        .regcea(1'b1),
        .douta(bram_dout_a),
        .addrb(bram_addr_b),
        .web(1'b0),
        .dinb('0),
        .enb(1'b1),
        .rstb(rst),
        .regceb(1'b1),
        .doutb(bram_dout_b)
    );

    // --- Line Buffers (register arrays) ---
    // prev_row: labels from the row above
    // curr_row: labels being computed for current row
    logic [LABEL_BITS-1:0] prev_row [0:WIDTH-1];
    logic [LABEL_BITS-1:0] curr_row [0:WIDTH-1];

    // --- Equivalence Table ---
    // equiv[i] = j means label i maps to label j
    // Initially equiv[i] = i (self-mapping)
    logic [LABEL_BITS-1:0] equiv [0:MAX_COMPONENTS-1];

    // --- Counters and State Variables ---
    logic [ADDR_BITS-1:0] pixel_idx;
    logic [X_BITS-1:0] curr_x;
    logic [Y_BITS-1:0] curr_y;
    logic [LABEL_BITS-1:0] next_label;      // Next available label
    logic [LABEL_BITS-1:0] chosen_label;    // Label chosen for current pixel
    logic curr_pixel;                        // Current pixel value (foreground/bg)

    // Conflict detection
    logic [LABEL_BITS-1:0] conflict_label1, conflict_label2;
    logic has_conflict;

    // Pass 2 state
    logic [ADDR_BITS-1:0] p2_pixel_idx;
    logic [X_BITS-1:0] p2_x;
    logic [Y_BITS-1:0] p2_y;
    logic [1:0] bram_read_delay;

    // Temporary variables for conflict detection (replacing automatic)
    logic [LABEL_BITS-1:0] min_label_tmp, other_label_tmp;
    logic found_conflict_tmp;
    
    // Temporary variables for equivalence resolution
    logic [LABEL_BITS-1:0] root1_tmp, root2_tmp, min_root_tmp, max_root_tmp;
    logic [LABEL_BITS-1:0] raw_label_tmp, final_label_tmp;

    // --- Neighbor Labels (computed combinationally) ---
    logic [LABEL_BITS-1:0] L, NW, N, NE;    // Left, NorthWest, North, NorthEast
    logic L_valid, NW_valid, N_valid, NE_valid;

    // Combinational neighbor lookup
    always_comb begin
        // Default: invalid (label 0 = background)
        L = '0; NW = '0; N = '0; NE = '0;
        L_valid = 1'b0; NW_valid = 1'b0; N_valid = 1'b0; NE_valid = 1'b0;

        // Left neighbor (same row, previous column)
        if (curr_x > 0) begin
            L = curr_row[curr_x - 1];
            L_valid = (L != '0);
        end

        // North neighbors (previous row)
        if (curr_y > 0) begin
            // NW (previous row, previous column)
            if (curr_x > 0) begin
                NW = prev_row[curr_x - 1];
                NW_valid = (NW != '0);
            end

            // N (previous row, same column)
            N = prev_row[curr_x];
            N_valid = (N != '0);

            // NE (previous row, next column)
            if (curr_x < WIDTH - 1) begin
                NE = prev_row[curr_x + 1];
                NE_valid = (NE != '0);
            end
        end
    end

    // --- Find root of equivalence chain ---
    function automatic [LABEL_BITS-1:0] find_root(
        input [LABEL_BITS-1:0] label
    );
        logic [LABEL_BITS-1:0] current;
        integer depth;
        current = label;
        // Follow chain (with depth limit to avoid synthesis issues)
        for (depth = 0; depth < MAX_COMPONENTS; depth = depth + 1) begin
            if (current == 0 || current >= MAX_COMPONENTS || equiv[current] == current) begin
                return current;
            end
            current = equiv[current];
        end
        return current;
    endfunction

    // --- Main FSM ---
    integer i;

    always_ff @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            pixel_idx <= '0;
            curr_x <= '0;
            curr_y <= '0;
            next_label <= 1;
            s_axis_ready <= 1'b0;
            m_axis_valid <= 1'b0;
            m_axis_last <= 1'b0;
            m_axis_label <= '0;
            m_axis_x <= '0;
            m_axis_y <= '0;
            bram_we <= 1'b0;
            bram_addr_a <= '0;
            bram_addr_b <= '0;
            bram_din <= '0;
            chosen_label <= '0;
            curr_pixel <= 1'b0;
            conflict_label1 <= '0;
            conflict_label2 <= '0;
            has_conflict <= 1'b0;
            p2_pixel_idx <= '0;
            p2_x <= '0;
            p2_y <= '0;
            bram_read_delay <= '0;

            // Initialize line buffers
            for (i = 0; i < WIDTH; i = i + 1) begin
                prev_row[i] <= '0;
                curr_row[i] <= '0;
            end

            // Initialize equivalence table (self-mapping)
            for (i = 0; i < MAX_COMPONENTS; i = i + 1) begin
                equiv[i] <= i[LABEL_BITS-1:0];
            end

        end else begin
            // Default: clear one-cycle signals
            bram_we <= 1'b0;
            m_axis_valid <= 1'b0;
            m_axis_last <= 1'b0;

            case (state)
                // ========================================
                // IDLE: Initialize for new frame
                // ========================================
                IDLE: begin
                    pixel_idx <= '0;
                    curr_x <= '0;
                    curr_y <= '0;
                    next_label <= 1;
                    has_conflict <= 1'b0;

                    // Clear line buffers
                    for (i = 0; i < WIDTH; i = i + 1) begin
                        prev_row[i] <= '0;
                        curr_row[i] <= '0;
                    end

                    // Reset equivalence table
                    for (i = 0; i < MAX_COMPONENTS; i = i + 1) begin
                        equiv[i] <= i[LABEL_BITS-1:0];
                    end

                    s_axis_ready <= 1'b1;
                    state <= PASS1_WAIT;
                end

                // ========================================
                // PASS1_WAIT: Wait for input pixel
                // ========================================
                PASS1_WAIT: begin
                    s_axis_ready <= 1'b1;
                    if (s_axis_valid) begin
                        curr_pixel <= s_axis_data;
                        s_axis_ready <= 1'b0;
                        state <= PASS1_LABEL;
                    end
                end

                // ========================================
                // PASS1_LABEL: Assign label to current pixel
                // ========================================
                PASS1_LABEL: begin
                    has_conflict <= 1'b0;

                    if (!curr_pixel) begin
                        // Background pixel: label = 0
                        chosen_label <= '0;
                    end else begin
                        // Foreground pixel: find label from neighbors or create new
                        // Priority: L > NW > N > NE > new label
                        
                        if (L_valid) begin
                            chosen_label <= L;
                        end else if (NW_valid) begin
                            chosen_label <= NW;
                        end else if (N_valid) begin
                            chosen_label <= N;
                        end else if (NE_valid) begin
                            chosen_label <= NE;
                        end else begin
                            // New component
                            chosen_label <= next_label;
                            if (next_label < MAX_COMPONENTS - 1) begin
                                next_label <= next_label + 1;
                            end
                        end

                        // Check for conflicts (different labels that should merge)
                        // This is the key 8-connectivity check
                        
                        // Find minimum non-zero label among neighbors
                        min_label_tmp = '0;
                        if (L_valid) min_label_tmp = L;
                        else if (NW_valid) min_label_tmp = NW;
                        else if (N_valid) min_label_tmp = N;
                        else if (NE_valid) min_label_tmp = NE;

                        found_conflict_tmp = 1'b0;
                        other_label_tmp = '0;

                        // Check if any other neighbor has different label
                        if (min_label_tmp != '0) begin
                            if (NW_valid && NW != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = NW;
                            end
                            if (N_valid && N != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = N;
                            end
                            if (NE_valid && NE != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = NE;
                            end
                            if (L_valid && L != min_label_tmp && !found_conflict_tmp) begin
                                found_conflict_tmp = 1'b1;
                                other_label_tmp = L;
                            end
                        end

                        if (found_conflict_tmp) begin
                            has_conflict <= 1'b1;
                            // Store smaller label first
                            if (min_label_tmp < other_label_tmp) begin
                                conflict_label1 <= min_label_tmp;
                                conflict_label2 <= other_label_tmp;
                            end else begin
                                conflict_label1 <= other_label_tmp;
                                conflict_label2 <= min_label_tmp;
                            end
                        end
                    end

                    // Write label to BRAM and line buffer
                    bram_addr_a <= pixel_idx;
                    bram_din <= curr_pixel ? (L_valid ? L : (NW_valid ? NW : (N_valid ? N : (NE_valid ? NE : next_label)))) : '0;
                    bram_we <= 1'b1;

                    // Update current row buffer
                    curr_row[curr_x] <= curr_pixel ? (L_valid ? L : (NW_valid ? NW : (N_valid ? N : (NE_valid ? NE : next_label)))) : '0;

                    // Handle conflict or advance
                    if (curr_pixel && has_conflict) begin
                        state <= PASS1_CONFLICT;
                    end else begin
                        // Advance to next pixel
                        if (pixel_idx == TOTAL_PIXELS - 1) begin
                            // End of Pass 1
                            p2_pixel_idx <= '0;
                            p2_x <= '0;
                            p2_y <= '0;
                            bram_addr_b <= '0;
                            bram_read_delay <= '0;
                            state <= PASS2_READ;
                        end else begin
                            pixel_idx <= pixel_idx + 1;
                            if (curr_x == WIDTH - 1) begin
                                // End of row: swap buffers
                                curr_x <= '0;
                                curr_y <= curr_y + 1;
                                for (i = 0; i < WIDTH; i = i + 1) begin
                                    prev_row[i] <= curr_row[i];
                                    curr_row[i] <= '0;
                                end
                            end else begin
                                curr_x <= curr_x + 1;
                            end
                            s_axis_ready <= 1'b1;
                            state <= PASS1_WAIT;
                        end
                    end
                end

                // ========================================
                // PASS1_CONFLICT: Update equivalence table
                // ========================================
                PASS1_CONFLICT: begin
                    // Merge the two conflicting labels in equivalence table
                    // Make the larger label point to the smaller
                    root1_tmp = find_root(conflict_label1);
                    root2_tmp = find_root(conflict_label2);
                    
                    if (root1_tmp != root2_tmp && root1_tmp != 0 && root2_tmp != 0) begin
                        if (root1_tmp < root2_tmp) begin
                            min_root_tmp = root1_tmp;
                            max_root_tmp = root2_tmp;
                        end else begin
                            min_root_tmp = root2_tmp;
                            max_root_tmp = root1_tmp;
                        end
                        // Point larger root to smaller
                        if (max_root_tmp < MAX_COMPONENTS) begin
                            equiv[max_root_tmp] <= min_root_tmp;
                        end
                    end

                    has_conflict <= 1'b0;

                    // Continue with next pixel
                    if (pixel_idx == TOTAL_PIXELS - 1) begin
                        p2_pixel_idx <= '0;
                        p2_x <= '0;
                        p2_y <= '0;
                        bram_addr_b <= '0;
                        bram_read_delay <= '0;
                        state <= PASS2_READ;
                    end else begin
                        pixel_idx <= pixel_idx + 1;
                        if (curr_x == WIDTH - 1) begin
                            curr_x <= '0;
                            curr_y <= curr_y + 1;
                            for (i = 0; i < WIDTH; i = i + 1) begin
                                prev_row[i] <= curr_row[i];
                                curr_row[i] <= '0;
                            end
                        end else begin
                            curr_x <= curr_x + 1;
                        end
                        s_axis_ready <= 1'b1;
                        state <= PASS1_WAIT;
                    end
                end

                // ========================================
                // PASS2_READ: Initiate BRAM read
                // ========================================
                PASS2_READ: begin
                    s_axis_ready <= 1'b0;
                    bram_addr_b <= p2_pixel_idx;
                    bram_read_delay <= 2'd0;
                    state <= PASS2_WAIT;
                end

                // ========================================
                // PASS2_WAIT: Wait for BRAM read (2 cycles for output register)
                // ========================================
                PASS2_WAIT: begin
                    if (bram_read_delay < 2'd2) begin
                        bram_read_delay <= bram_read_delay + 1;
                    end else begin
                        state <= PASS2_OUTPUT;
                    end
                end

                // ========================================
                // PASS2_OUTPUT: Apply equivalence and output
                // ========================================
                PASS2_OUTPUT: begin
                    raw_label_tmp = bram_dout_b;
                    
                    if (raw_label_tmp == 0) begin
                        final_label_tmp = 0;
                    end else begin
                        final_label_tmp = find_root(raw_label_tmp);
                    end

                    m_axis_valid <= 1'b1;
                    m_axis_label <= final_label_tmp;
                    m_axis_x <= p2_x;
                    m_axis_y <= p2_y;
                    m_axis_last <= (p2_pixel_idx == TOTAL_PIXELS - 1);

                    if (m_axis_ready || !m_axis_valid) begin
                        if (p2_pixel_idx == TOTAL_PIXELS - 1) begin
                            state <= DONE;
                        end else begin
                            p2_pixel_idx <= p2_pixel_idx + 1;
                            if (p2_x == WIDTH - 1) begin
                                p2_x <= '0;
                                p2_y <= p2_y + 1;
                            end else begin
                                p2_x <= p2_x + 1;
                            end
                            state <= PASS2_READ;
                        end
                    end
                end

                // ========================================
                // DONE: Frame complete, return to IDLE
                // ========================================
                DONE: begin
                    m_axis_valid <= 1'b0;
                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule

`default_nettype wire

